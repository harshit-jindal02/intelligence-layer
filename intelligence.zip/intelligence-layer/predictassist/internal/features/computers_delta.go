package features

import (
	"context"
	"fmt"
)

// ErrorRateDeltaComputer computes the change in error rate compared to the
// previous window of the same size. A positive value means errors are increasing.
type ErrorRateDeltaComputer struct{}

func (c *ErrorRateDeltaComputer) Compute(ctx context.Context, input ComputeInput) (float64, error) {
	// Current window error rate.
	currentCount, err := input.CHStore.CountLogsBySeverity(ctx, input.Service, "ERROR", input.Start, input.End)
	if err != nil {
		return 0, fmt.Errorf("count current errors: %w", err)
	}

	// Previous window error rate.
	prevStart := input.Start.Add(-input.Window)
	prevEnd := input.Start
	prevCount, err := input.CHStore.CountLogsBySeverity(ctx, input.Service, "ERROR", prevStart, prevEnd)
	if err != nil {
		return 0, fmt.Errorf("count previous errors: %w", err)
	}

	seconds := input.Window.Seconds()
	if seconds == 0 {
		return 0, nil
	}

	currentRate := float64(currentCount) / seconds
	prevRate := float64(prevCount) / seconds

	if prevRate == 0 {
		if currentRate > 0 {
			return currentRate, nil // All new errors
		}
		return 0, nil
	}

	return currentRate - prevRate, nil
}

// LatencyDeltaComputer computes the change in average latency compared to the
// previous window.
type LatencyDeltaComputer struct{}

func (c *LatencyDeltaComputer) Compute(ctx context.Context, input ComputeInput) (float64, error) {
	currentAvg, err := input.CHStore.LatencyAvg(ctx, input.Service, input.Start, input.End)
	if err != nil {
		return 0, fmt.Errorf("current latency avg: %w", err)
	}

	prevStart := input.Start.Add(-input.Window)
	prevEnd := input.Start
	prevAvg, err := input.CHStore.LatencyAvg(ctx, input.Service, prevStart, prevEnd)
	if err != nil {
		return 0, fmt.Errorf("previous latency avg: %w", err)
	}

	return currentAvg - prevAvg, nil
}
