package features

import (
	"context"
	"fmt"
)

// LatencyPercentileComputer computes a percentile of span duration in the window.
type LatencyPercentileComputer struct {
	Percentile float64 // 50, 95, 99 etc.
}

func (c *LatencyPercentileComputer) Compute(ctx context.Context, input ComputeInput) (float64, error) {
	val, err := input.CHStore.LatencyPercentile(ctx, input.Service, c.Percentile, input.Start, input.End)
	if err != nil {
		return 0, fmt.Errorf("latency p%v: %w", c.Percentile, err)
	}
	return val, nil
}

// LatencyAvgComputer computes the average span duration in milliseconds.
type LatencyAvgComputer struct{}

func (c *LatencyAvgComputer) Compute(ctx context.Context, input ComputeInput) (float64, error) {
	val, err := input.CHStore.LatencyAvg(ctx, input.Service, input.Start, input.End)
	if err != nil {
		return 0, fmt.Errorf("latency avg: %w", err)
	}
	return val, nil
}
