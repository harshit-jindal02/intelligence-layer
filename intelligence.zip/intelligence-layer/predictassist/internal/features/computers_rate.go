package features

import (
	"context"
	"fmt"
)

// ErrorRateComputer computes the error rate (errors per second) by counting
// ERROR-severity log records in the window.
type ErrorRateComputer struct{}

func (c *ErrorRateComputer) Compute(ctx context.Context, input ComputeInput) (float64, error) {
	count, err := input.CHStore.CountLogsBySeverity(ctx, input.Service, "ERROR", input.Start, input.End)
	if err != nil {
		return 0, fmt.Errorf("count error logs: %w", err)
	}
	seconds := input.Window.Seconds()
	if seconds == 0 {
		return 0, nil
	}
	return float64(count) / seconds, nil
}

// RequestRateComputer computes the request rate (spans per second) by
// counting trace spans in the window.
type RequestRateComputer struct{}

func (c *RequestRateComputer) Compute(ctx context.Context, input ComputeInput) (float64, error) {
	count, err := input.CHStore.CountTraces(ctx, input.Service, input.Start, input.End)
	if err != nil {
		return 0, fmt.Errorf("count traces: %w", err)
	}
	seconds := input.Window.Seconds()
	if seconds == 0 {
		return 0, nil
	}
	return float64(count) / seconds, nil
}

// LogVolumeComputer computes the total number of log records in the window.
type LogVolumeComputer struct{}

func (c *LogVolumeComputer) Compute(ctx context.Context, input ComputeInput) (float64, error) {
	count, err := input.CHStore.CountLogs(ctx, input.Service, input.Start, input.End)
	if err != nil {
		return 0, fmt.Errorf("count logs: %w", err)
	}
	return float64(count), nil
}
