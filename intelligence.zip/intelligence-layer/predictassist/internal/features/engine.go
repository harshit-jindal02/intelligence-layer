// Package features provides the feature computation engine that transforms
// raw telemetry data (logs, metrics, traces) into behavioural features
// for anomaly detection. Features are computed over configurable sliding
// time windows and stored in ClickHouse + Redis.
package features

import (
	"context"
	"fmt"
	"log"
	"sync"
	"time"

	"github.com/harshitjindal/predictassist/internal/models"
	"github.com/harshitjindal/predictassist/internal/store"
)

// Engine coordinates the computation of behavioural features from raw
// telemetry data. It runs on a configurable interval, reading recent data
// from ClickHouse, computing features, and writing results back to
// ClickHouse + Redis.
type Engine struct {
	chStore    *store.ClickHouseStore
	redisStore *store.RedisStore
	registry   *Registry
	cfg        EngineConfig

	mu      sync.Mutex
	started bool
}

// EngineConfig holds configuration for the feature engine.
type EngineConfig struct {
	// ComputeInterval is how often features are computed.
	ComputeInterval time.Duration

	// Windows are the time window sizes to compute features over.
	Windows []time.Duration

	// Services is the list of services to compute features for.
	// If empty, all known services are used.
	Services []string
}

// NewEngine creates a feature evaluation engine.
func NewEngine(ch *store.ClickHouseStore, redis *store.RedisStore, cfg EngineConfig) *Engine {
	if cfg.ComputeInterval == 0 {
		cfg.ComputeInterval = 10 * time.Second
	}
	if len(cfg.Windows) == 0 {
		cfg.Windows = []time.Duration{1 * time.Minute, 5 * time.Minute, 15 * time.Minute}
	}

	return &Engine{
		chStore:    ch,
		redisStore: redis,
		registry:   NewRegistry(),
		cfg:        cfg,
	}
}

// Registry returns the feature registry for adding custom feature definitions.
func (e *Engine) Registry() *Registry {
	return e.registry
}

// Run starts the feature computation loop. It blocks until ctx is cancelled.
func (e *Engine) Run(ctx context.Context) {
	e.mu.Lock()
	if e.started {
		e.mu.Unlock()
		return
	}
	e.started = true
	e.mu.Unlock()

	log.Printf("feature engine: started (interval=%s, windows=%v)", e.cfg.ComputeInterval, e.cfg.Windows)

	ticker := time.NewTicker(e.cfg.ComputeInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			log.Printf("feature engine: stopped")
			return
		case <-ticker.C:
			e.computeAll(ctx)
		}
	}
}

// computeAll runs all registered feature computations for all windows.
func (e *Engine) computeAll(ctx context.Context) {
	services, err := e.chStore.GetKnownServices(ctx)
	if err != nil {
		log.Printf("feature engine: failed to get services: %v", err)
		return
	}

	if len(e.cfg.Services) > 0 {
		services = e.cfg.Services
	}

	for _, svc := range services {
		for _, window := range e.cfg.Windows {
			e.computeForServiceWindow(ctx, svc, window)
		}
	}
}

// computeForServiceWindow computes all registered features for a single
// service and time window.
func (e *Engine) computeForServiceWindow(ctx context.Context, service string, window time.Duration) {
	now := time.Now().UTC()
	start := now.Add(-window)

	defs := e.registry.All()
	results := make([]models.ComputedFeature, 0, len(defs))

	for _, def := range defs {
		value, err := def.Computer.Compute(ctx, ComputeInput{
			Service:  service,
			Window:   window,
			Start:    start,
			End:      now,
			CHStore:  e.chStore,
		})
		if err != nil {
			log.Printf("feature engine: %s/%s/%s error: %v", service, def.Name, window, err)
			continue
		}

		feat := models.ComputedFeature{
			Timestamp: now,
			Service:   service,
			Name:      def.Name,
			Value:     value,
			Window:    fmt.Sprintf("%s", window),
		}
		results = append(results, feat)

		// Cache in Redis.
		if e.redisStore != nil {
			_ = e.redisStore.SetFeature(ctx, store.FeatureValue{
				Service:   service,
				Name:      def.Name,
				Value:     value,
				Window:    feat.Window,
				Timestamp: now,
			}, window*2)
		}
	}

	if len(results) > 0 {
		if err := e.chStore.InsertComputedFeatures(ctx, results); err != nil {
			log.Printf("feature engine: failed to write features for %s/%s: %v", service, window, err)
		}
	}
}
