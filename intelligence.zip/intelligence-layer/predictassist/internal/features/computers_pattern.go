package features

import (
	"context"
	"fmt"
	"math"
)

// UniqueErrorTypesComputer counts the number of unique error message patterns
// in the window. A sudden increase in unique error types is a signal of
// new failure modes emerging.
type UniqueErrorTypesComputer struct{}

func (c *UniqueErrorTypesComputer) Compute(ctx context.Context, input ComputeInput) (float64, error) {
	count, err := input.CHStore.CountUniqueErrorMessages(ctx, input.Service, input.Start, input.End)
	if err != nil {
		return 0, fmt.Errorf("count unique errors: %w", err)
	}
	return float64(count), nil
}

// LogEntropyComputer computes the Shannon entropy of the log severity
// distribution. High entropy means a balanced mix of severities; low entropy
// means one severity dominates. A shift in entropy can indicate a change in
// system behaviour.
type LogEntropyComputer struct{}

func (c *LogEntropyComputer) Compute(ctx context.Context, input ComputeInput) (float64, error) {
	counts, err := input.CHStore.CountLogsBySeverityAll(ctx, input.Service, input.Start, input.End)
	if err != nil {
		return 0, fmt.Errorf("severity counts: %w", err)
	}

	var total float64
	for _, count := range counts {
		total += float64(count)
	}
	if total == 0 {
		return 0, nil
	}

	var entropy float64
	for _, count := range counts {
		if count == 0 {
			continue
		}
		p := float64(count) / total
		entropy -= p * math.Log2(p)
	}

	return entropy, nil
}
