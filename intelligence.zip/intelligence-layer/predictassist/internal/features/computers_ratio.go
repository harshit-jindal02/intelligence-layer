package features

import (
	"context"
	"fmt"
)

// ErrorToTotalRatioComputer computes the ratio of error spans to total spans.
type ErrorToTotalRatioComputer struct{}

func (c *ErrorToTotalRatioComputer) Compute(ctx context.Context, input ComputeInput) (float64, error) {
	total, err := input.CHStore.CountTraces(ctx, input.Service, input.Start, input.End)
	if err != nil {
		return 0, fmt.Errorf("count total traces: %w", err)
	}
	if total == 0 {
		return 0, nil
	}
	errors, err := input.CHStore.CountErrorTraces(ctx, input.Service, input.Start, input.End)
	if err != nil {
		return 0, fmt.Errorf("count error traces: %w", err)
	}
	return float64(errors) / float64(total), nil
}

// WarnToInfoRatioComputer computes the ratio of WARN logs to INFO logs.
type WarnToInfoRatioComputer struct{}

func (c *WarnToInfoRatioComputer) Compute(ctx context.Context, input ComputeInput) (float64, error) {
	infoCount, err := input.CHStore.CountLogsBySeverity(ctx, input.Service, "INFO", input.Start, input.End)
	if err != nil {
		return 0, fmt.Errorf("count info logs: %w", err)
	}
	if infoCount == 0 {
		return 0, nil
	}
	warnCount, err := input.CHStore.CountLogsBySeverity(ctx, input.Service, "WARN", input.Start, input.End)
	if err != nil {
		return 0, fmt.Errorf("count warn logs: %w", err)
	}
	return float64(warnCount) / float64(infoCount), nil
}
