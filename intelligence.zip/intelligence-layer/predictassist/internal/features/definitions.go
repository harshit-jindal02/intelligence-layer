package features

import (
	"context"
	"time"

	"github.com/harshitjindal/predictassist/internal/store"
)

// ComputeInput provides the context needed by a FeatureComputer to perform
// its calculation.
type ComputeInput struct {
	Service string
	Window  time.Duration
	Start   time.Time
	End     time.Time
	CHStore *store.ClickHouseStore
}

// FeatureComputer is the interface that all feature computation algorithms
// must implement.
type FeatureComputer interface {
	// Compute calculates the feature value for the given input context.
	Compute(ctx context.Context, input ComputeInput) (float64, error)
}

// FeatureDefinition describes a registered feature.
type FeatureDefinition struct {
	// Name is the unique identifier (e.g. "error_rate", "latency_p99").
	Name string

	// Category classifies the feature (rate, distribution, ratio, delta, pattern).
	Category string

	// Description explains what this feature measures.
	Description string

	// Computer is the algorithm that computes the feature value.
	Computer FeatureComputer
}

// Registry holds all registered feature definitions.
type Registry struct {
	defs []FeatureDefinition
}

// NewRegistry creates an empty feature registry and registers all built-in features.
func NewRegistry() *Registry {
	r := &Registry{}
	r.RegisterBuiltins()
	return r
}

// Register adds a feature definition to the registry.
func (r *Registry) Register(def FeatureDefinition) {
	r.defs = append(r.defs, def)
}

// All returns all registered feature definitions.
func (r *Registry) All() []FeatureDefinition {
	return r.defs
}

// RegisterBuiltins registers all built-in feature computers.
func (r *Registry) RegisterBuiltins() {
	// Rate features
	r.Register(FeatureDefinition{
		Name:        "error_rate",
		Category:    "rate",
		Description: "Error log rate (errors per second) in the window",
		Computer:    &ErrorRateComputer{},
	})
	r.Register(FeatureDefinition{
		Name:        "request_rate",
		Category:    "rate",
		Description: "Request rate (traces per second) in the window",
		Computer:    &RequestRateComputer{},
	})
	r.Register(FeatureDefinition{
		Name:        "log_volume",
		Category:    "rate",
		Description: "Total log volume in the window",
		Computer:    &LogVolumeComputer{},
	})

	// Distribution features
	r.Register(FeatureDefinition{
		Name:        "latency_p50",
		Category:    "distribution",
		Description: "Median (p50) latency in the window",
		Computer:    &LatencyPercentileComputer{Percentile: 50},
	})
	r.Register(FeatureDefinition{
		Name:        "latency_p95",
		Category:    "distribution",
		Description: "95th percentile latency in the window",
		Computer:    &LatencyPercentileComputer{Percentile: 95},
	})
	r.Register(FeatureDefinition{
		Name:        "latency_p99",
		Category:    "distribution",
		Description: "99th percentile latency in the window",
		Computer:    &LatencyPercentileComputer{Percentile: 99},
	})
	r.Register(FeatureDefinition{
		Name:        "latency_avg",
		Category:    "distribution",
		Description: "Average latency in the window",
		Computer:    &LatencyAvgComputer{},
	})

	// Ratio features
	r.Register(FeatureDefinition{
		Name:        "error_to_total_ratio",
		Category:    "ratio",
		Description: "Ratio of error spans to total spans",
		Computer:    &ErrorToTotalRatioComputer{},
	})
	r.Register(FeatureDefinition{
		Name:        "warn_to_info_ratio",
		Category:    "ratio",
		Description: "Ratio of WARN logs to INFO logs",
		Computer:    &WarnToInfoRatioComputer{},
	})

	// Delta features
	r.Register(FeatureDefinition{
		Name:        "error_rate_delta",
		Category:    "delta",
		Description: "Change in error rate compared to previous window",
		Computer:    &ErrorRateDeltaComputer{},
	})
	r.Register(FeatureDefinition{
		Name:        "latency_delta",
		Category:    "delta",
		Description: "Change in avg latency compared to previous window",
		Computer:    &LatencyDeltaComputer{},
	})

	// Pattern features
	r.Register(FeatureDefinition{
		Name:        "unique_error_types",
		Category:    "pattern",
		Description: "Count of unique error message patterns in the window",
		Computer:    &UniqueErrorTypesComputer{},
	})
	r.Register(FeatureDefinition{
		Name:        "log_entropy",
		Category:    "pattern",
		Description: "Shannon entropy of log severity distribution",
		Computer:    &LogEntropyComputer{},
	})
}
