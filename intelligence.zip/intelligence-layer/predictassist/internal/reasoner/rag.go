package reasoner

import (
	"context"
	"fmt"
	"log"
	"time"

	"github.com/harshitjindal/predictassist/internal/store"
	pkgmodels "github.com/harshitjindal/predictassist/pkg/models"
)

// RAGRetriever performs retrieval-augmented generation by fetching relevant
// historical data from ClickHouse to enrich LLM prompts.
type RAGRetriever struct {
	chStore *store.ClickHouseStore
}

// RAGContext holds the retrieved context for prompt augmentation.
type RAGContext struct {
	// SimilarIncidents are past incidents matching the current fingerprint.
	SimilarIncidents []HistoricalIncident

	// BaselineStats are rolling baseline statistics for key features.
	BaselineStats map[string]BaselineStat
}

// HistoricalIncident represents a past incident retrieved for context.
type HistoricalIncident struct {
	Timestamp      time.Time
	Service        string
	Category       string
	Severity       string
	Description    string
	RootCause      string
	ResolutionTime string
}

// BaselineStat holds summary statistics for a feature.
type BaselineStat struct {
	Mean   float64
	StdDev float64
}

// NewRAGRetriever creates a RAG retriever.
func NewRAGRetriever(ch *store.ClickHouseStore) *RAGRetriever {
	return &RAGRetriever{chStore: ch}
}

// Retrieve fetches context relevant to the given prediction.
func (r *RAGRetriever) Retrieve(ctx context.Context, pred pkgmodels.IncidentPrediction) (*RAGContext, error) {
	result := &RAGContext{
		BaselineStats: make(map[string]BaselineStat),
	}

	// 1. Fetch similar historical incidents from the predictions table.
	incidents, err := r.fetchSimilarIncidents(ctx, pred)
	if err != nil {
		log.Printf("rag: failed to fetch historical incidents: %v", err)
		// Non-fatal — continue with partial context.
	} else {
		result.SimilarIncidents = incidents
	}

	// 2. Fetch baseline statistics for features mentioned in anomaly rules.
	if len(pred.AffectedServices) > 0 {
		service := pred.AffectedServices[0]
		for _, rule := range pred.MatchedRules {
			if !rule.Matched {
				continue
			}
			stats, err := r.fetchBaselineStats(ctx, service, rule.Name)
			if err != nil {
				continue
			}
			result.BaselineStats[rule.Name] = stats
		}
	}

	return result, nil
}

// fetchSimilarIncidents queries past predictions with the same fingerprint.
func (r *RAGRetriever) fetchSimilarIncidents(ctx context.Context, pred pkgmodels.IncidentPrediction) ([]HistoricalIncident, error) {
	rows, err := r.chStore.Query(ctx, `
		SELECT timestamp, service, category, severity, description
		FROM incident_predictions
		WHERE category = $1 AND timestamp < now() - INTERVAL 1 HOUR
		ORDER BY timestamp DESC
		LIMIT 5
	`, pred.Fingerprint.Category)
	if err != nil {
		return nil, fmt.Errorf("query historical incidents: %w", err)
	}
	defer rows.Close()

	var incidents []HistoricalIncident
	for rows.Next() {
		var inc HistoricalIncident
		if err := rows.Scan(&inc.Timestamp, &inc.Service, &inc.Category, &inc.Severity, &inc.Description); err != nil {
			continue
		}
		incidents = append(incidents, inc)
	}
	return incidents, nil
}

// fetchBaselineStats computes rolling mean and std dev for a feature.
func (r *RAGRetriever) fetchBaselineStats(ctx context.Context, service, featureName string) (BaselineStat, error) {
	since := time.Now().UTC().Add(-24 * time.Hour)
	values, err := r.chStore.GetFeatureHistory(ctx, service, featureName, "5m", since)
	if err != nil || len(values) < 2 {
		return BaselineStat{}, fmt.Errorf("insufficient data for baseline")
	}

	mean := 0.0
	for _, v := range values {
		mean += v
	}
	mean /= float64(len(values))

	variance := 0.0
	for _, v := range values {
		diff := v - mean
		variance += diff * diff
	}
	variance /= float64(len(values))

	return BaselineStat{
		Mean:   mean,
		StdDev: sqrt(variance),
	}, nil
}

func sqrt(x float64) float64 {
	if x <= 0 {
		return 0
	}
	// Newton's method.
	z := x
	for i := 0; i < 20; i++ {
		z = z - (z*z-x)/(2*z)
	}
	return z
}
