package reasoner

import (
	"fmt"
	"strings"

	"github.com/harshitjindal/predictassist/internal/models"
	pkgmodels "github.com/harshitjindal/predictassist/pkg/models"
)

// PromptBuilder constructs structured prompts for the LLM provider.
type PromptBuilder struct {
	maxTokens int
}

// NewPromptBuilder creates a PromptBuilder.
func NewPromptBuilder(maxTokens int) *PromptBuilder {
	return &PromptBuilder{maxTokens: maxTokens}
}

// Build constructs a prompt from the prediction, RAG context, and anomaly details.
func (pb *PromptBuilder) Build(
	pred pkgmodels.IncidentPrediction,
	ragCtx *RAGContext,
	anomalies []models.AnomalyRecord,
) string {
	var b strings.Builder

	// System instruction.
	b.WriteString(systemPrompt)
	b.WriteString("\n\n")

	// Current prediction context.
	b.WriteString("## Current Prediction\n")
	b.WriteString(fmt.Sprintf("- **Fingerprint**: %s (%s)\n", pred.Fingerprint.Hash, pred.Fingerprint.Category))
	b.WriteString(fmt.Sprintf("- **Service**: %s\n", strings.Join(pred.AffectedServices, ", ")))
	b.WriteString(fmt.Sprintf("- **Probability**: %.0f%%\n", pred.Probability*100))
	b.WriteString(fmt.Sprintf("- **Severity**: %s\n", pred.Severity))
	b.WriteString(fmt.Sprintf("- **Estimated Lead Time**: %s\n", pred.TimeToIncident))
	b.WriteString(fmt.Sprintf("- **Anomaly Count**: %d\n\n", len(pred.AnomalyIDs)))

	// Matched rules.
	if len(pred.MatchedRules) > 0 {
		b.WriteString("## Matched Anomaly Rules\n")
		for _, r := range pred.MatchedRules {
			status := "NOT matched"
			if r.Matched {
				status = "MATCHED"
			}
			b.WriteString(fmt.Sprintf("- %s: %s [%s]\n", r.Name, r.Description, status))
		}
		b.WriteString("\n")
	}

	// Recent anomaly details.
	if len(anomalies) > 0 {
		b.WriteString("## Recent Anomalies\n")
		shown := min(len(anomalies), 10)
		for i := 0; i < shown; i++ {
			a := anomalies[i]
			b.WriteString(fmt.Sprintf("- [%s] %s: %s (value=%.4f, baseline=%.4f, z_score=%.2f, severity=%s)\n",
				a.Timestamp.Format("15:04:05"), a.Service, a.FeatureName,
				a.Value, a.Baseline, a.ZScore, a.Severity))
		}
		b.WriteString("\n")
	}

	// RAG context: historical incidents.
	if ragCtx != nil && len(ragCtx.SimilarIncidents) > 0 {
		b.WriteString("## Historical Context (Similar Past Incidents)\n")
		for _, inc := range ragCtx.SimilarIncidents {
			b.WriteString(fmt.Sprintf("- [%s] %s: %s (severity=%s, resolved_in=%s)\n",
				inc.Timestamp.Format("2006-01-02 15:04"),
				inc.Service,
				inc.Description,
				inc.Severity,
				inc.ResolutionTime,
			))
			if inc.RootCause != "" {
				b.WriteString(fmt.Sprintf("  Root cause: %s\n", inc.RootCause))
			}
		}
		b.WriteString("\n")
	}

	// Baseline statistics from RAG.
	if ragCtx != nil && len(ragCtx.BaselineStats) > 0 {
		b.WriteString("## Service Baselines\n")
		for feature, stat := range ragCtx.BaselineStats {
			b.WriteString(fmt.Sprintf("- %s: mean=%.4f, std=%.4f\n", feature, stat.Mean, stat.StdDev))
		}
		b.WriteString("\n")
	}

	// Output format instruction.
	b.WriteString(outputFormatPrompt)

	// Truncate if too long (rough estimate: 1 token ≈ 4 chars).
	result := b.String()
	maxChars := pb.maxTokens * 4
	if len(result) > maxChars {
		result = result[:maxChars-100] + "\n\n[Context truncated for token limit]"
	}

	return result
}

const systemPrompt = `You are PredictAssist, an expert AI SRE assistant that analyzes 
telemetry anomalies and predicts incidents before they fully manifest.

Your task: Given a set of correlated anomalies and a predicted incident fingerprint,
generate actionable insights that help an on-call engineer prevent or mitigate the
incident.

Guidelines:
1. Be concise and specific — engineers are under time pressure.
2. Reference specific metrics and their deviations.
3. Suggest concrete actions (scale up, restart, roll back, check specific component).
4. Rate your confidence in each insight.
5. If historical incidents are available, reference what worked before.
6. Consider the estimated lead time when prioritising actions.`

const outputFormatPrompt = `## Response Format
Return a JSON array of insights, each with these fields:
- "summary": One-line description of the insight (max 200 chars)
- "detail": Extended explanation with evidence (max 500 chars)
- "confidence": Your confidence in this insight (0.0 to 1.0)
- "suggested_action": A concrete action the engineer can take (max 200 chars)

Return 2-5 insights, ordered by priority. Example:
[
  {
    "summary": "Database connection pool approaching exhaustion",
    "detail": "Latency p99 has increased 3x while error rate climbed from 0.1% to 5%. This pattern matches historical DB pool exhaustion events where connections are leaked under high load.",
    "confidence": 0.85,
    "suggested_action": "Scale up DB connection pool from 50 to 100 and check for leaked connections in the payment service."
  }
]`

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
