// Package reasoner generates actionable insights for incident predictions
// by combining LLM reasoning with retrieval-augmented generation (RAG)
// over historical incidents.
package reasoner

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"sync"
	"time"

	"github.com/harshitjindal/predictassist/internal/events"
	"github.com/harshitjindal/predictassist/internal/models"
	"github.com/harshitjindal/predictassist/internal/store"
	pkgmodels "github.com/harshitjindal/predictassist/pkg/models"
)

// Engine subscribes to prediction events, enriches them with context via
// RAG, calls an LLM provider to generate insights, and publishes the
// enriched prediction back.
type Engine struct {
	provider   LLMProvider
	chStore    *store.ClickHouseStore
	eventBus   *events.EventBus
	cache      *Cache
	rag        *RAGRetriever
	prompt     *PromptBuilder
	cfg        EngineConfig

	mu      sync.Mutex
	started bool
}

// EngineConfig holds configuration for the reasoner engine.
type EngineConfig struct {
	// MaxConcurrent limits the number of parallel LLM calls.
	MaxConcurrent int

	// Timeout per individual LLM call.
	Timeout time.Duration

	// CacheTTL is how long a cached insight response is valid.
	CacheTTL time.Duration

	// MaxContextTokens limits how many tokens of context are sent to the LLM.
	MaxContextTokens int
}

// NewEngine creates a new reasoner engine.
func NewEngine(
	provider LLMProvider,
	ch *store.ClickHouseStore,
	bus *events.EventBus,
	cache *Cache,
	cfg EngineConfig,
) *Engine {
	if cfg.MaxConcurrent == 0 {
		cfg.MaxConcurrent = 4
	}
	if cfg.Timeout == 0 {
		cfg.Timeout = 30 * time.Second
	}
	if cfg.CacheTTL == 0 {
		cfg.CacheTTL = 10 * time.Minute
	}
	if cfg.MaxContextTokens == 0 {
		cfg.MaxContextTokens = 4096
	}

	return &Engine{
		provider: provider,
		chStore:  ch,
		eventBus: bus,
		cache:    cache,
		rag:      NewRAGRetriever(ch),
		prompt:   NewPromptBuilder(cfg.MaxContextTokens),
		cfg:      cfg,
	}
}

// Run starts the reasoner event loop by subscribing to prediction events.
func (e *Engine) Run(ctx context.Context) {
	e.mu.Lock()
	if e.started {
		e.mu.Unlock()
		return
	}
	e.started = true
	e.mu.Unlock()

	log.Printf("reasoner engine: started (concurrency=%d, timeout=%s)",
		e.cfg.MaxConcurrent, e.cfg.Timeout)

	// Subscribe to prediction events and process in parallel.
	sem := make(chan struct{}, e.cfg.MaxConcurrent)

	handler := func(handlerCtx context.Context, event events.Event) error {
		sem <- struct{}{}
		go func() {
			defer func() { <-sem }()
			e.handlePrediction(ctx, event)
		}()
		return nil
	}

	if e.eventBus != nil {
		_, err := e.eventBus.Subscribe(ctx, events.SubjectPredictionCreated, "reasoner", handler)
		if err != nil {
			log.Printf("reasoner engine: subscribe failed: %v", err)
		}
	}

	<-ctx.Done()
	log.Printf("reasoner engine: stopped")
}

// handlePrediction processes a single prediction event.
func (e *Engine) handlePrediction(ctx context.Context, event events.Event) {
	var prediction pkgmodels.IncidentPrediction
	if err := event.DecodePayload(&prediction); err != nil {
		log.Printf("reasoner: decode prediction: %v", err)
		return
	}

	// Check cache first.
	cacheKey := prediction.Fingerprint.Hash + ":" + prediction.AffectedServices[0]
	if cached, ok := e.cache.Get(ctx, cacheKey); ok {
		prediction.Insights = cached
		e.publishUpdated(ctx, prediction)
		log.Printf("reasoner: cache hit for %s", cacheKey)
		return
	}

	// Gather context via RAG.
	ragCtx, err := e.rag.Retrieve(ctx, prediction)
	if err != nil {
		log.Printf("reasoner: RAG retrieval failed: %v", err)
		// Continue without RAG context.
	}

	// Fetch recent anomaly details for prompt enrichment.
	var anomalyDetails []models.AnomalyRecord
	if len(prediction.AffectedServices) > 0 {
		since := time.Now().UTC().Add(-30 * time.Minute)
		records, err := e.chStore.QueryRecentAnomalies(ctx, prediction.AffectedServices[0], since, 20)
		if err == nil {
			anomalyDetails = records
		}
	}

	// Build prompt.
	prompt := e.prompt.Build(prediction, ragCtx, anomalyDetails)

	// Call LLM with timeout.
	callCtx, cancel := context.WithTimeout(ctx, e.cfg.Timeout)
	defer cancel()

	response, err := e.provider.Complete(callCtx, prompt)
	if err != nil {
		log.Printf("reasoner: LLM call failed: %v", err)
		// Generate a fallback insight from the fingerprint match alone.
		prediction.Insights = fallbackInsights(prediction)
		e.publishUpdated(ctx, prediction)
		return
	}

	// Parse structured insights from LLM response.
	insights := parseInsights(response)
	prediction.Insights = insights

	// Cache the result.
	e.cache.Set(ctx, cacheKey, insights, e.cfg.CacheTTL)

	// Publish the enriched prediction.
	e.publishUpdated(ctx, prediction)
	log.Printf("reasoner: enriched prediction %s with %d insights", prediction.ID, len(insights))
}

func (e *Engine) publishUpdated(ctx context.Context, pred pkgmodels.IncidentPrediction) {
	if e.eventBus == nil {
		return
	}
	event, err := events.NewEvent(pred.ID, events.SubjectPredictionUpdated, "reasoner", pred)
	if err != nil {
		log.Printf("reasoner: failed to create event: %v", err)
		return
	}
	if err := e.eventBus.Publish(ctx, events.SubjectPredictionUpdated, event); err != nil {
		log.Printf("reasoner: failed to publish updated prediction: %v", err)
	}
}

// parseInsights attempts to extract structured insights from the LLM response.
func parseInsights(response string) []pkgmodels.Insight {
	// Try JSON array first.
	var insights []pkgmodels.Insight
	if err := json.Unmarshal([]byte(response), &insights); err == nil && len(insights) > 0 {
		return insights
	}

	// Try JSON object with "insights" key.
	var wrapper struct {
		Insights []pkgmodels.Insight `json:"insights"`
	}
	if err := json.Unmarshal([]byte(response), &wrapper); err == nil && len(wrapper.Insights) > 0 {
		return wrapper.Insights
	}

	// Fallback: treat entire response as a single insight.
	return []pkgmodels.Insight{
		{
			Summary:    truncateString(response, 200),
			Detail:     response,
			Confidence: 0.7,
		},
	}
}

// fallbackInsights generates basic insights without LLM when the provider
// is unavailable or fails.
func fallbackInsights(pred pkgmodels.IncidentPrediction) []pkgmodels.Insight {
	return []pkgmodels.Insight{
		{
			Summary: fmt.Sprintf("Potential %s incident predicted for %s",
				pred.Fingerprint.Category, pred.AffectedServices[0]),
			Detail: fmt.Sprintf(
				"Based on %d correlated anomalies, a %s incident is predicted with %.0f%% probability. "+
					"Estimated lead time: %s.",
				len(pred.AnomalyIDs),
				pred.Fingerprint.Category,
				pred.Probability*100,
				pred.TimeToIncident,
			),
			Confidence:      pred.Probability * 0.8,
			SuggestedAction: "Investigate the flagged anomalies and check service health dashboards.",
		},
	}
}

func truncateString(s string, maxLen int) string {
	if len(s) <= maxLen {
		return s
	}
	return s[:maxLen-3] + "..."
}
