package reasoner

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/redis/go-redis/v9"

	pkgmodels "github.com/harshitjindal/predictassist/pkg/models"
)

// Cache provides a Redis-backed response cache for LLM insights to avoid
// redundant (and expensive) LLM calls for the same prediction fingerprint.
type Cache struct {
	rdb       *redis.Client
	keyPrefix string
}

// NewCache creates a new insight cache backed by Redis.
func NewCache(rdb *redis.Client) *Cache {
	return &Cache{
		rdb:       rdb,
		keyPrefix: "predictassist:reasoner:cache:",
	}
}

// Get retrieves cached insights for the given key.
// Returns (insights, true) on cache hit, or (nil, false) on miss.
func (c *Cache) Get(ctx context.Context, key string) ([]pkgmodels.Insight, bool) {
	if c.rdb == nil {
		return nil, false
	}

	data, err := c.rdb.Get(ctx, c.keyPrefix+key).Bytes()
	if err != nil {
		return nil, false
	}

	var insights []pkgmodels.Insight
	if err := json.Unmarshal(data, &insights); err != nil {
		return nil, false
	}

	return insights, true
}

// Set stores insights in the cache with the given TTL.
func (c *Cache) Set(ctx context.Context, key string, insights []pkgmodels.Insight, ttl time.Duration) {
	if c.rdb == nil {
		return
	}

	data, err := json.Marshal(insights)
	if err != nil {
		return
	}

	c.rdb.Set(ctx, c.keyPrefix+key, data, ttl)
}

// Invalidate removes a cached entry.
func (c *Cache) Invalidate(ctx context.Context, key string) {
	if c.rdb == nil {
		return
	}
	c.rdb.Del(ctx, c.keyPrefix+key)
}

// InvalidateAll removes all cached entries with the cache prefix.
func (c *Cache) InvalidateAll(ctx context.Context) error {
	if c.rdb == nil {
		return nil
	}

	iter := c.rdb.Scan(ctx, 0, c.keyPrefix+"*", 100).Iterator()
	var keys []string
	for iter.Next(ctx) {
		keys = append(keys, iter.Val())
	}
	if err := iter.Err(); err != nil {
		return fmt.Errorf("scan cache keys: %w", err)
	}

	if len(keys) > 0 {
		c.rdb.Del(ctx, keys...)
	}
	return nil
}
