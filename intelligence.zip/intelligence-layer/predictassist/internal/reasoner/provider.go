package reasoner

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"
)

// LLMProvider is the interface for calling an LLM to generate insights.
type LLMProvider interface {
	// Complete sends a prompt to the LLM and returns the response text.
	Complete(ctx context.Context, prompt string) (string, error)

	// Name returns the provider name for logging.
	Name() string
}

// ------------------- Ollama Provider -------------------

// OllamaProvider calls a local Ollama instance for LLM inference.
type OllamaProvider struct {
	baseURL string
	model   string
	client  *http.Client
}

// OllamaConfig holds configuration for the Ollama provider.
type OllamaConfig struct {
	// BaseURL is the Ollama API endpoint (default: "http://localhost:11434").
	BaseURL string

	// Model is the model name to use (default: "llama3.1").
	Model string

	// Timeout for HTTP requests.
	Timeout time.Duration
}

// NewOllamaProvider creates a new Ollama LLM provider.
func NewOllamaProvider(cfg OllamaConfig) *OllamaProvider {
	if cfg.BaseURL == "" {
		cfg.BaseURL = "http://localhost:11434"
	}
	if cfg.Model == "" {
		cfg.Model = "llama3.1"
	}
	if cfg.Timeout == 0 {
		cfg.Timeout = 60 * time.Second
	}

	return &OllamaProvider{
		baseURL: cfg.BaseURL,
		model:   cfg.Model,
		client:  &http.Client{Timeout: cfg.Timeout},
	}
}

func (o *OllamaProvider) Name() string {
	return fmt.Sprintf("ollama/%s", o.model)
}

func (o *OllamaProvider) Complete(ctx context.Context, prompt string) (string, error) {
	reqBody := map[string]any{
		"model":  o.model,
		"prompt": prompt,
		"stream": false,
		"options": map[string]any{
			"temperature": 0.3,
			"num_predict": 2048,
		},
	}

	body, err := json.Marshal(reqBody)
	if err != nil {
		return "", fmt.Errorf("marshal request: %w", err)
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, o.baseURL+"/api/generate", bytes.NewReader(body))
	if err != nil {
		return "", fmt.Errorf("create request: %w", err)
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := o.client.Do(req)
	if err != nil {
		return "", fmt.Errorf("ollama request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		respBody, _ := io.ReadAll(resp.Body)
		return "", fmt.Errorf("ollama error (status=%d): %s", resp.StatusCode, string(respBody))
	}

	var result struct {
		Response string `json:"response"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return "", fmt.Errorf("decode ollama response: %w", err)
	}

	return result.Response, nil
}

// ------------------- OpenAI-Compatible Provider -------------------

// OpenAIProvider calls an OpenAI-compatible API (OpenAI, Azure, vLLM, etc.).
type OpenAIProvider struct {
	baseURL string
	apiKey  string
	model   string
	client  *http.Client
}

// OpenAIConfig holds configuration for an OpenAI-compatible provider.
type OpenAIConfig struct {
	// BaseURL is the API endpoint (default: "https://api.openai.com/v1").
	BaseURL string

	// APIKey is the authentication key.
	APIKey string

	// Model is the model identifier (default: "gpt-4o-mini").
	Model string

	// Timeout for HTTP requests.
	Timeout time.Duration
}

// NewOpenAIProvider creates a new OpenAI-compatible LLM provider.
func NewOpenAIProvider(cfg OpenAIConfig) *OpenAIProvider {
	if cfg.BaseURL == "" {
		cfg.BaseURL = "https://api.openai.com/v1"
	}
	if cfg.Model == "" {
		cfg.Model = "gpt-4o-mini"
	}
	if cfg.Timeout == 0 {
		cfg.Timeout = 60 * time.Second
	}

	return &OpenAIProvider{
		baseURL: cfg.BaseURL,
		apiKey:  cfg.APIKey,
		model:   cfg.Model,
		client:  &http.Client{Timeout: cfg.Timeout},
	}
}

func (o *OpenAIProvider) Name() string {
	return fmt.Sprintf("openai/%s", o.model)
}

func (o *OpenAIProvider) Complete(ctx context.Context, prompt string) (string, error) {
	reqBody := map[string]any{
		"model": o.model,
		"messages": []map[string]string{
			{"role": "user", "content": prompt},
		},
		"temperature": 0.3,
		"max_tokens":  2048,
	}

	body, err := json.Marshal(reqBody)
	if err != nil {
		return "", fmt.Errorf("marshal request: %w", err)
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, o.baseURL+"/chat/completions", bytes.NewReader(body))
	if err != nil {
		return "", fmt.Errorf("create request: %w", err)
	}
	req.Header.Set("Content-Type", "application/json")
	if o.apiKey != "" {
		req.Header.Set("Authorization", "Bearer "+o.apiKey)
	}

	resp, err := o.client.Do(req)
	if err != nil {
		return "", fmt.Errorf("openai request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		respBody, _ := io.ReadAll(resp.Body)
		return "", fmt.Errorf("openai error (status=%d): %s", resp.StatusCode, string(respBody))
	}

	var result struct {
		Choices []struct {
			Message struct {
				Content string `json:"content"`
			} `json:"message"`
		} `json:"choices"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return "", fmt.Errorf("decode openai response: %w", err)
	}

	if len(result.Choices) == 0 {
		return "", fmt.Errorf("openai returned no choices")
	}

	return result.Choices[0].Message.Content, nil
}

// ------------------- No-Op Provider (for testing / fallback) -------------------

// NoOpProvider returns canned responses for testing without an LLM.
type NoOpProvider struct{}

func NewNoOpProvider() *NoOpProvider { return &NoOpProvider{} }

func (n *NoOpProvider) Name() string { return "noop" }

func (n *NoOpProvider) Complete(_ context.Context, _ string) (string, error) {
	return `[{"summary":"Automated analysis unavailable","detail":"The LLM provider is not configured. This is a fallback response based on pattern matching alone.","confidence":0.5,"suggested_action":"Configure an LLM provider (Ollama or OpenAI) for richer insights."}]`, nil
}
