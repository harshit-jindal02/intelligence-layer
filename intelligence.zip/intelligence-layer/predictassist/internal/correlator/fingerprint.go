package correlator

import (
	"time"

	"github.com/harshitjindal/predictassist/internal/models"
)

// SignalDirection indicates whether an anomaly is an increase ("up") or
// decrease ("down") from the baseline.
type SignalDirection string

const (
	DirectionUp   SignalDirection = "up"
	DirectionDown SignalDirection = "down"
	DirectionAny  SignalDirection = "any"
)

// RequiredSignal is a single anomaly pattern element inside a fingerprint.
type RequiredSignal struct {
	// FeatureName is the computed feature that must be anomalous.
	FeatureName string

	// Direction indicates whether the anomaly is above or below baseline.
	Direction SignalDirection

	// MinSeverity is the minimum severity of the anomaly to match.
	MinSeverity string

	// Window restricts the match to a specific evaluation window.
	Window string
}

// Fingerprint describes a known incident pattern as a set of required and
// optional anomaly signals. When a sufficient subset of signals is observed,
// the correlator predicts the incident.
type Fingerprint struct {
	// ID is a unique identifier for this fingerprint.
	ID string

	// Name is a human-readable name.
	Name string

	// Category classifies the incident type.
	Category string

	// Description explains what this fingerprint detects.
	Description string

	// RequiredSignals must all be present for a match.
	RequiredSignals []RequiredSignal

	// OptionalSignals increase confidence when present.
	OptionalSignals []RequiredSignal

	// MinRequiredMatch is the minimum fraction of RequiredSignals that must
	// be matched (0.0..1.0). Default 1.0 means ALL required must match.
	MinRequiredMatch float64

	// EstimatedLeadTime is how far in advance the fingerprint typically
	// predicts the incident (e.g. "5m", "15m").
	EstimatedLeadTime string

	// BaseSeverity is the default severity if not further escalated.
	BaseSeverity string
}

// MatchResult is the output of a fingerprint match attempt.
type MatchResult struct {
	// Confidence is a value from 0 to 1 indicating how strongly the
	// fingerprint matched the observed anomalies.
	Confidence float64

	// Severity is the predicted severity.
	Severity string

	// MatchedAnomalies are the anomaly records that contributed to the match.
	MatchedAnomalies []models.AnomalyRecord

	// MatchedRequired is the number of required signals matched.
	MatchedRequired int

	// MatchedOptional is the number of optional signals matched.
	MatchedOptional int
}

// Match evaluates this fingerprint against a set of recent anomaly records
// and returns a MatchResult.
func (fp *Fingerprint) Match(anomalies []models.AnomalyRecord) MatchResult {
	if len(fp.RequiredSignals) == 0 {
		return MatchResult{}
	}

	minMatch := fp.MinRequiredMatch
	if minMatch == 0 {
		minMatch = 1.0
	}

	matchedAnomalies := make([]models.AnomalyRecord, 0)
	reqMatched := 0
	for _, req := range fp.RequiredSignals {
		if a, ok := findMatchingAnomaly(anomalies, req); ok {
			reqMatched++
			matchedAnomalies = append(matchedAnomalies, a)
		}
	}

	reqFraction := float64(reqMatched) / float64(len(fp.RequiredSignals))
	if reqFraction < minMatch {
		return MatchResult{Confidence: reqFraction * 0.5} // below threshold
	}

	optMatched := 0
	for _, opt := range fp.OptionalSignals {
		if a, ok := findMatchingAnomaly(anomalies, opt); ok {
			optMatched++
			matchedAnomalies = append(matchedAnomalies, a)
		}
	}

	confidence := computeConfidence(reqFraction, optMatched, len(fp.OptionalSignals))
	severity := escalateSeverity(fp.BaseSeverity, confidence)

	return MatchResult{
		Confidence:       confidence,
		Severity:         severity,
		MatchedAnomalies: matchedAnomalies,
		MatchedRequired:  reqMatched,
		MatchedOptional:  optMatched,
	}
}

// BuiltinFingerprints returns the default set of fingerprints.
func BuiltinFingerprints() []Fingerprint {
	return []Fingerprint{
		dbPoolExhaustion(),
		memoryLeak(),
		cascadeFailure(),
		latencyDegradation(),
		errorSurge(),
	}
}

func dbPoolExhaustion() Fingerprint {
	return Fingerprint{
		ID:       "fp-db-pool-exhaustion",
		Name:     "Database Pool Exhaustion",
		Category: "resource_exhaustion",
		Description: "Detects the pattern: rising latency → error surge → total outage " +
			"caused by database connection pool exhaustion.",
		RequiredSignals: []RequiredSignal{
			{FeatureName: "latency_p99", Direction: DirectionUp, MinSeverity: "medium", Window: "5m"},
			{FeatureName: "error_rate", Direction: DirectionUp, MinSeverity: "medium", Window: "5m"},
		},
		OptionalSignals: []RequiredSignal{
			{FeatureName: "latency_avg", Direction: DirectionUp, MinSeverity: "low", Window: "5m"},
			{FeatureName: "request_rate", Direction: DirectionDown, MinSeverity: "low", Window: "5m"},
		},
		MinRequiredMatch:  1.0,
		EstimatedLeadTime: "5m",
		BaseSeverity:      "high",
	}
}

func memoryLeak() Fingerprint {
	return Fingerprint{
		ID:       "fp-memory-leak",
		Name:     "Memory Leak",
		Category: "resource_exhaustion",
		Description: "Detects the pattern: steadily increasing latency with error rate delta, " +
			"characteristic of a memory leak approaching OOM.",
		RequiredSignals: []RequiredSignal{
			{FeatureName: "latency_p95", Direction: DirectionUp, MinSeverity: "medium", Window: "5m"},
			{FeatureName: "error_rate_delta", Direction: DirectionUp, MinSeverity: "low", Window: "5m"},
		},
		OptionalSignals: []RequiredSignal{
			{FeatureName: "latency_delta", Direction: DirectionUp, MinSeverity: "low", Window: "5m"},
			{FeatureName: "unique_error_types", Direction: DirectionUp, MinSeverity: "low", Window: "5m"},
		},
		MinRequiredMatch:  1.0,
		EstimatedLeadTime: "10m",
		BaseSeverity:      "high",
	}
}

func cascadeFailure() Fingerprint {
	return Fingerprint{
		ID:       "fp-cascade-failure",
		Name:     "Cascade Failure",
		Category: "cascade_failure",
		Description: "Detects correlated error surges across multiple features, " +
			"typically indicative of a cascading failure between services.",
		RequiredSignals: []RequiredSignal{
			{FeatureName: "error_rate", Direction: DirectionUp, MinSeverity: "high", Window: "5m"},
			{FeatureName: "error_to_total_ratio", Direction: DirectionUp, MinSeverity: "medium", Window: "5m"},
		},
		OptionalSignals: []RequiredSignal{
			{FeatureName: "latency_p99", Direction: DirectionUp, MinSeverity: "medium", Window: "5m"},
			{FeatureName: "unique_error_types", Direction: DirectionUp, MinSeverity: "low", Window: "5m"},
			{FeatureName: "log_volume", Direction: DirectionUp, MinSeverity: "low", Window: "5m"},
		},
		MinRequiredMatch:  1.0,
		EstimatedLeadTime: "3m",
		BaseSeverity:      "critical",
	}
}

func latencyDegradation() Fingerprint {
	return Fingerprint{
		ID:       "fp-latency-degradation",
		Name:     "Latency Degradation",
		Category: "performance",
		Description: "Detects gradual latency increase that precedes user-visible " +
			"performance problems.",
		RequiredSignals: []RequiredSignal{
			{FeatureName: "latency_p95", Direction: DirectionUp, MinSeverity: "medium", Window: "5m"},
			{FeatureName: "latency_delta", Direction: DirectionUp, MinSeverity: "low", Window: "5m"},
		},
		OptionalSignals: []RequiredSignal{
			{FeatureName: "latency_avg", Direction: DirectionUp, MinSeverity: "low", Window: "5m"},
		},
		MinRequiredMatch:  1.0,
		EstimatedLeadTime: "15m",
		BaseSeverity:      "medium",
	}
}

func errorSurge() Fingerprint {
	return Fingerprint{
		ID:       "fp-error-surge",
		Name:     "Error Surge",
		Category: "error_spike",
		Description: "Detects a sudden spike in errors combined with new error types, " +
			"often caused by a bad deployment or configuration change.",
		RequiredSignals: []RequiredSignal{
			{FeatureName: "error_rate", Direction: DirectionUp, MinSeverity: "high", Window: "5m"},
			{FeatureName: "unique_error_types", Direction: DirectionUp, MinSeverity: "medium", Window: "5m"},
		},
		OptionalSignals: []RequiredSignal{
			{FeatureName: "error_rate_delta", Direction: DirectionUp, MinSeverity: "low", Window: "5m"},
			{FeatureName: "warn_to_info_ratio", Direction: DirectionUp, MinSeverity: "low", Window: "5m"},
		},
		MinRequiredMatch:  1.0,
		EstimatedLeadTime: "5m",
		BaseSeverity:      "high",
	}
}

// findMatchingAnomaly returns the first anomaly that matches a signal
// requirement, or false if no match found.
func findMatchingAnomaly(anomalies []models.AnomalyRecord, req RequiredSignal) (models.AnomalyRecord, bool) {
	sevRank := severityRank(req.MinSeverity)

	for _, a := range anomalies {
		if a.FeatureName != req.FeatureName {
			continue
		}
		if req.Window != "" && a.Window != req.Window {
			continue
		}
		if severityRank(a.Severity) < sevRank {
			continue
		}

		switch req.Direction {
		case DirectionUp:
			if a.ZScore <= 0 {
				continue
			}
		case DirectionDown:
			if a.ZScore >= 0 {
				continue
			}
		case DirectionAny:
			// any direction matches
		}

		// Check the anomaly is recent (within 30-minute lookback by default).
		if time.Since(a.Timestamp) > 30*time.Minute {
			continue
		}

		return a, true
	}
	return models.AnomalyRecord{}, false
}

func severityRank(sev string) int {
	switch sev {
	case "critical":
		return 4
	case "high":
		return 3
	case "medium":
		return 2
	case "low":
		return 1
	default:
		return 0
	}
}

func computeConfidence(reqFraction float64, optMatched, totalOptional int) float64 {
	// Base confidence from required signal match.
	base := reqFraction * 0.75

	// Bonus from optional signals.
	if totalOptional > 0 {
		optFraction := float64(optMatched) / float64(totalOptional)
		base += optFraction * 0.25
	} else {
		base += 0.10 // small bonus if there are no optional signals
	}

	if base > 1.0 {
		base = 1.0
	}
	return base
}

func escalateSeverity(baseSeverity string, confidence float64) string {
	if confidence >= 0.9 {
		if baseSeverity == "high" {
			return "critical"
		}
		if baseSeverity == "medium" {
			return "high"
		}
	}
	return baseSeverity
}
