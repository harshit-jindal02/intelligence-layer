package correlator

import (
	"math"
)

// Scorer computes confidence scores for fingerprint matches with adjustments
// based on signal recency, severity weighting, and temporal ordering.
type Scorer struct {
	// RecencyWeight controls how much recency affects the score (0-1).
	RecencyWeight float64

	// SeverityWeight controls how much severity affects the score (0-1).
	SeverityWeight float64

	// SequenceWeight controls how much temporal sequence match affects the
	// overall score (0-1).
	SequenceWeight float64
}

// NewScorer creates a Scorer with default weights.
func NewScorer() *Scorer {
	return &Scorer{
		RecencyWeight:  0.20,
		SeverityWeight: 0.30,
		SequenceWeight: 0.50,
	}
}

// ScoreInput collects the inputs needed to compute a final confidence score.
type ScoreInput struct {
	// BaseMatch is the raw fingerprint match result.
	BaseMatch MatchResult

	// SequenceResult is the temporal sequence match result, if available.
	SequenceResult *SequenceMatchResult

	// Fingerprint is the fingerprint that was matched.
	Fingerprint Fingerprint
}

// ScoreResult holds the final computed score.
type ScoreResult struct {
	// FinalConfidence is the combined confidence after all adjustments.
	FinalConfidence float64

	// BaseScore is the raw fingerprint match confidence.
	BaseScore float64

	// RecencyAdjustment is the recency bonus/penalty applied.
	RecencyAdjustment float64

	// SeverityAdjustment is the severity bonus applied.
	SeverityAdjustment float64

	// SequenceAdjustment is the temporal ordering bonus applied.
	SequenceAdjustment float64
}

// Score computes the final confidence score for a match.
func (s *Scorer) Score(input ScoreInput) ScoreResult {
	base := input.BaseMatch.Confidence
	if base == 0 {
		return ScoreResult{}
	}

	// --- Recency adjustment ---
	recencyAdj := 0.0
	if len(input.BaseMatch.MatchedAnomalies) > 0 {
		// Average age of matched anomalies — more recent = higher score.
		totalAgeMinutes := 0.0
		for _, a := range input.BaseMatch.MatchedAnomalies {
			ageMin := max(1.0, float64(a.Timestamp.Unix())/60.0)
			totalAgeMinutes += ageMin
		}
		// Decay: newer anomalies (low age) produce a higher recency score.
		avgAge := totalAgeMinutes / float64(len(input.BaseMatch.MatchedAnomalies))
		recencyAdj = 1.0 / (1.0 + math.Log1p(avgAge/5.0))
	}

	// --- Severity adjustment ---
	sevAdj := 0.0
	maxSev := 0
	for _, a := range input.BaseMatch.MatchedAnomalies {
		rank := severityRank(a.Severity)
		if rank > maxSev {
			maxSev = rank
		}
	}
	sevAdj = float64(maxSev) / 4.0 // normalise to 0-1

	// --- Sequence adjustment ---
	seqAdj := 0.0
	if input.SequenceResult != nil {
		seqAdj = input.SequenceResult.Score
	}

	// Weighted combination.
	finalConfidence := base*0.40 +
		recencyAdj*s.RecencyWeight +
		sevAdj*s.SeverityWeight +
		seqAdj*s.SequenceWeight

	// Clamp to [0, 1].
	if finalConfidence > 1.0 {
		finalConfidence = 1.0
	}
	if finalConfidence < 0 {
		finalConfidence = 0
	}

	return ScoreResult{
		FinalConfidence:    finalConfidence,
		BaseScore:          base,
		RecencyAdjustment:  recencyAdj,
		SeverityAdjustment: sevAdj,
		SequenceAdjustment: seqAdj,
	}
}
