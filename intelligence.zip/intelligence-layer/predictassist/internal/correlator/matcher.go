package correlator

import (
	"sort"
	"time"

	"github.com/harshitjindal/predictassist/internal/models"
)

// SequenceMatcher detects temporal ordering of anomalies to improve
// fingerprint matching accuracy. Many incident types exhibit a predictable
// progression (e.g. latency rise → error surge → cascading failure).
type SequenceMatcher struct {
	// MaxGap is the maximum time between consecutive signals in a sequence.
	MaxGap time.Duration
}

// NewSequenceMatcher creates a SequenceMatcher with default settings.
func NewSequenceMatcher() *SequenceMatcher {
	return &SequenceMatcher{
		MaxGap: 10 * time.Minute,
	}
}

// SequenceStep defines one step in an expected temporal sequence.
type SequenceStep struct {
	FeatureName string
	Direction   SignalDirection
}

// SequencePattern describes an ordered list of anomaly signals expected
// to appear in temporal order.
type SequencePattern struct {
	Steps []SequenceStep
}

// SequenceMatchResult describes the result of matching a sequence pattern.
type SequenceMatchResult struct {
	// MatchedSteps is the number of steps that were matched in order.
	MatchedSteps int
	// TotalSteps is the total number of steps in the pattern.
	TotalSteps int
	// Matched anomalies in sequence order.
	Matched []models.AnomalyRecord
	// Score is MatchedSteps / TotalSteps.
	Score float64
}

// Match attempts to find the given temporal sequence within the anomaly records.
// Records are sorted by time, and the matcher greedily matches steps in order.
func (sm *SequenceMatcher) Match(anomalies []models.AnomalyRecord, pattern SequencePattern) SequenceMatchResult {
	if len(pattern.Steps) == 0 {
		return SequenceMatchResult{TotalSteps: 0, Score: 1.0}
	}

	// Sort anomalies chronologically (oldest first).
	sorted := make([]models.AnomalyRecord, len(anomalies))
	copy(sorted, anomalies)
	sort.Slice(sorted, func(i, j int) bool {
		return sorted[i].Timestamp.Before(sorted[j].Timestamp)
	})

	matched := make([]models.AnomalyRecord, 0)
	stepIdx := 0
	var lastMatchTime time.Time

	for _, a := range sorted {
		if stepIdx >= len(pattern.Steps) {
			break
		}

		step := pattern.Steps[stepIdx]

		// Check feature name matches.
		if a.FeatureName != step.FeatureName {
			continue
		}

		// Check direction.
		if step.Direction == DirectionUp && a.ZScore <= 0 {
			continue
		}
		if step.Direction == DirectionDown && a.ZScore >= 0 {
			continue
		}

		// Check gap from previous match.
		if len(matched) > 0 && a.Timestamp.Sub(lastMatchTime) > sm.MaxGap {
			// Gap too large — reset.
			matched = matched[:0]
			stepIdx = 0
			continue
		}

		matched = append(matched, a)
		lastMatchTime = a.Timestamp
		stepIdx++
	}

	score := 0.0
	if len(pattern.Steps) > 0 {
		score = float64(len(matched)) / float64(len(pattern.Steps))
	}

	return SequenceMatchResult{
		MatchedSteps: len(matched),
		TotalSteps:   len(pattern.Steps),
		Matched:      matched,
		Score:        score,
	}
}

// BuiltinSequences returns predefined temporal sequence patterns.
func BuiltinSequences() map[string]SequencePattern {
	return map[string]SequencePattern{
		"fp-db-pool-exhaustion": {
			Steps: []SequenceStep{
				{FeatureName: "latency_p99", Direction: DirectionUp},
				{FeatureName: "error_rate", Direction: DirectionUp},
				{FeatureName: "request_rate", Direction: DirectionDown},
			},
		},
		"fp-memory-leak": {
			Steps: []SequenceStep{
				{FeatureName: "latency_p95", Direction: DirectionUp},
				{FeatureName: "latency_delta", Direction: DirectionUp},
				{FeatureName: "error_rate_delta", Direction: DirectionUp},
			},
		},
		"fp-cascade-failure": {
			Steps: []SequenceStep{
				{FeatureName: "error_rate", Direction: DirectionUp},
				{FeatureName: "error_to_total_ratio", Direction: DirectionUp},
				{FeatureName: "latency_p99", Direction: DirectionUp},
			},
		},
	}
}
