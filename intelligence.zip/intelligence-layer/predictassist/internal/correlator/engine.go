// Package correlator matches detected anomaly patterns against known incident
// fingerprints to predict incidents before they fully manifest.
package correlator

import (
	"context"
	"fmt"
	"log"
	"sync"
	"time"

	"github.com/google/uuid"
	"github.com/harshitjindal/predictassist/internal/events"
	"github.com/harshitjindal/predictassist/internal/models"
	"github.com/harshitjindal/predictassist/internal/store"
	pkgmodels "github.com/harshitjindal/predictassist/pkg/models"
)

// Engine coordinates incident fingerprint matching.
type Engine struct {
	chStore      *store.ClickHouseStore
	eventBus     *events.EventBus
	fingerprints []Fingerprint
	cfg          EngineConfig

	mu      sync.Mutex
	started bool
}

// EngineConfig holds configuration for the correlator engine.
type EngineConfig struct {
	// EvalInterval is how often the engine evaluates for matches.
	EvalInterval time.Duration

	// LookbackWindow is how far back to look for anomalies when matching.
	LookbackWindow time.Duration

	// MinConfidence is the minimum match confidence to generate a prediction.
	MinConfidence float64
}

// NewEngine creates a new correlator engine.
func NewEngine(ch *store.ClickHouseStore, bus *events.EventBus, cfg EngineConfig) *Engine {
	if cfg.EvalInterval == 0 {
		cfg.EvalInterval = 30 * time.Second
	}
	if cfg.LookbackWindow == 0 {
		cfg.LookbackWindow = 30 * time.Minute
	}
	if cfg.MinConfidence == 0 {
		cfg.MinConfidence = 0.6
	}

	e := &Engine{
		chStore:  ch,
		eventBus: bus,
		cfg:      cfg,
	}

	// Load built-in fingerprints.
	e.fingerprints = BuiltinFingerprints()

	return e
}

// AddFingerprint registers a new incident fingerprint.
func (e *Engine) AddFingerprint(fp Fingerprint) {
	e.mu.Lock()
	defer e.mu.Unlock()
	e.fingerprints = append(e.fingerprints, fp)
}

// Fingerprints returns the current fingerprint library.
func (e *Engine) Fingerprints() []Fingerprint {
	e.mu.Lock()
	defer e.mu.Unlock()
	result := make([]Fingerprint, len(e.fingerprints))
	copy(result, e.fingerprints)
	return result
}

// Run starts the correlation evaluation loop.
func (e *Engine) Run(ctx context.Context) {
	e.mu.Lock()
	if e.started {
		e.mu.Unlock()
		return
	}
	e.started = true
	e.mu.Unlock()

	log.Printf("correlator engine: started (interval=%s, lookback=%s, min_confidence=%.2f, fingerprints=%d)",
		e.cfg.EvalInterval, e.cfg.LookbackWindow, e.cfg.MinConfidence, len(e.fingerprints))

	ticker := time.NewTicker(e.cfg.EvalInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			log.Printf("correlator engine: stopped")
			return
		case <-ticker.C:
			e.evaluate(ctx)
		}
	}
}

// evaluate checks all services against all fingerprints.
func (e *Engine) evaluate(ctx context.Context) {
	services, err := e.chStore.GetKnownServices(ctx)
	if err != nil {
		log.Printf("correlator: failed to get services: %v", err)
		return
	}

	since := time.Now().UTC().Add(-e.cfg.LookbackWindow)

	for _, svc := range services {
		anomalies, err := e.chStore.QueryRecentAnomalies(ctx, svc, since, 200)
		if err != nil || len(anomalies) == 0 {
			continue
		}

		for _, fp := range e.fingerprints {
			match := fp.Match(anomalies)
			if match.Confidence < e.cfg.MinConfidence {
				continue
			}

			prediction := pkgmodels.IncidentPrediction{
				ID: uuid.New().String(),
				Fingerprint: pkgmodels.IncidentFingerprint{
					ServiceName: svc,
					Category:    fp.Category,
					Hash:        fp.ID,
				},
				PredictedAt:      time.Now().UTC(),
				Probability:      match.Confidence,
				Severity:         pkgmodels.AnomalySeverity(match.Severity),
				TimeToIncident:   fp.EstimatedLeadTime,
				AnomalyIDs:       anomalyIDs(match.MatchedAnomalies),
				MatchedRules:     toAnomalyRules(fp, match),
				AffectedServices: []string{svc},
			}

			e.publishPrediction(ctx, prediction)
			log.Printf("correlator: PREDICTION — %s in %s (confidence=%.2f, severity=%s, lead_time=%s)",
				fp.Name, svc, match.Confidence, match.Severity, fp.EstimatedLeadTime)
		}
	}
}

func (e *Engine) publishPrediction(ctx context.Context, pred pkgmodels.IncidentPrediction) {
	if e.eventBus == nil {
		return
	}
	event, err := events.NewEvent(pred.ID, events.SubjectPredictionCreated, "correlator", pred)
	if err != nil {
		log.Printf("correlator: failed to create event: %v", err)
		return
	}
	if err := e.eventBus.Publish(ctx, events.SubjectPredictionCreated, event); err != nil {
		log.Printf("correlator: failed to publish prediction: %v", err)
	}
}

func anomalyIDs(anomalies []models.AnomalyRecord) []string {
	ids := make([]string, len(anomalies))
	for i, a := range anomalies {
		ids[i] = a.ID
	}
	return ids
}

func toAnomalyRules(fp Fingerprint, match MatchResult) []pkgmodels.AnomalyRule {
	var rules []pkgmodels.AnomalyRule
	for _, req := range fp.RequiredSignals {
		matched := false
		for _, a := range match.MatchedAnomalies {
			if a.FeatureName == req.FeatureName {
				matched = true
				break
			}
		}
		rules = append(rules, pkgmodels.AnomalyRule{
			Name:        req.FeatureName,
			Description: fmt.Sprintf("Anomaly in %s (%s deviation)", req.FeatureName, req.Direction),
			Condition:   fmt.Sprintf("%s %s threshold", req.FeatureName, req.Direction),
			Matched:     matched,
		})
	}
	return rules
}
