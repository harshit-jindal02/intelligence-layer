// Package api provides the REST API server for PredictAssist, exposing
// endpoints for querying anomalies, predictions, fingerprints, features, and
// system health.
package api

import (
	"net/http"
	"time"

	"github.com/gin-gonic/gin"

	"github.com/harshitjindal/predictassist/internal/correlator"
	"github.com/harshitjindal/predictassist/internal/store"
)

// Server wraps a Gin engine and exposes PredictAssist RESTful endpoints.
type Server struct {
	router  *gin.Engine
	chStore *store.ClickHouseStore
	corr    *correlator.Engine
	cfg     ServerConfig
}

// ServerConfig holds configuration for the API server.
type ServerConfig struct {
	Port         int
	ReadTimeout  time.Duration
	WriteTimeout time.Duration
	CORSOrigins  []string
}

// NewServer creates a new REST API server.
func NewServer(ch *store.ClickHouseStore, corr *correlator.Engine, cfg ServerConfig) *Server {
	if cfg.ReadTimeout == 0 {
		cfg.ReadTimeout = 30 * time.Second
	}
	if cfg.WriteTimeout == 0 {
		cfg.WriteTimeout = 30 * time.Second
	}

	gin.SetMode(gin.ReleaseMode)
	router := gin.New()
	router.Use(gin.Recovery())
	router.Use(corsMiddleware(cfg.CORSOrigins))

	s := &Server{
		router:  router,
		chStore: ch,
		corr:    corr,
		cfg:     cfg,
	}

	s.registerRoutes()
	return s
}

// Handler returns the underlying http.Handler for use with http.Server.
func (s *Server) Handler() http.Handler {
	return s.router
}

func (s *Server) registerRoutes() {
	v1 := s.router.Group("/api/v1")
	{
		// Health
		v1.GET("/health", s.handleHealth)

		// Anomalies
		v1.GET("/anomalies", s.handleListAnomalies)
		v1.GET("/anomalies/:service", s.handleGetServiceAnomalies)

		// Predictions
		v1.GET("/predictions", s.handleListPredictions)

		// Features
		v1.GET("/features/:service", s.handleGetServiceFeatures)
		v1.GET("/features/:service/:name/history", s.handleGetFeatureHistory)

		// Fingerprints
		v1.GET("/fingerprints", s.handleListFingerprints)

		// Services
		v1.GET("/services", s.handleListServices)
	}
}

func corsMiddleware(origins []string) gin.HandlerFunc {
	return func(c *gin.Context) {
		origin := "*"
		if len(origins) > 0 && origins[0] != "*" {
			origin = origins[0]
		}
		c.Header("Access-Control-Allow-Origin", origin)
		c.Header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		c.Header("Access-Control-Allow-Headers", "Origin, Content-Type, Accept, Authorization")
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(http.StatusNoContent)
			return
		}
		c.Next()
	}
}
