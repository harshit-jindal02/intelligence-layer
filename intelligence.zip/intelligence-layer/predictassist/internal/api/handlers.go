package api

import (
	"fmt"
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
)

// handleHealth returns the service health status.
func (s *Server) handleHealth(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"status":    "ok",
		"timestamp": time.Now().UTC().Format(time.RFC3339),
		"version":   "1.0.0",
	})
}

// handleListAnomalies returns recent anomaly events across all services.
func (s *Server) handleListAnomalies(c *gin.Context) {
	since := parseSince(c, 1*time.Hour)
	limit := parseLimit(c, 100)

	services, err := s.chStore.GetKnownServices(c.Request.Context())
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to list services"})
		return
	}

	type anomalyResponse struct {
		Service   string      `json:"service"`
		Anomalies interface{} `json:"anomalies"`
	}

	var results []anomalyResponse
	for _, svc := range services {
		records, err := s.chStore.QueryRecentAnomalies(c.Request.Context(), svc, since, limit)
		if err != nil {
			continue
		}
		if len(records) > 0 {
			results = append(results, anomalyResponse{Service: svc, Anomalies: records})
		}
	}

	c.JSON(http.StatusOK, gin.H{
		"anomalies": results,
		"since":     since.Format(time.RFC3339),
		"count":     len(results),
	})
}

// handleGetServiceAnomalies returns anomalies for a specific service.
func (s *Server) handleGetServiceAnomalies(c *gin.Context) {
	service := c.Param("service")
	since := parseSince(c, 1*time.Hour)
	limit := parseLimit(c, 100)

	records, err := s.chStore.QueryRecentAnomalies(c.Request.Context(), service, since, limit)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": fmt.Sprintf("failed to query anomalies: %v", err)})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"service":   service,
		"anomalies": records,
		"since":     since.Format(time.RFC3339),
		"count":     len(records),
	})
}

// handleListPredictions returns recent incident predictions.
func (s *Server) handleListPredictions(c *gin.Context) {
	since := parseSince(c, 1*time.Hour)
	limit := parseLimit(c, 50)

	rows, err := s.chStore.Query(c.Request.Context(), `
		SELECT id, timestamp, service, category, fingerprint_id,
			   probability, severity, time_to_incident, description, status
		FROM incident_predictions
		WHERE timestamp >= $1
		ORDER BY timestamp DESC
		LIMIT $2
	`, since, limit)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to query predictions"})
		return
	}
	defer rows.Close()

	type predictionRow struct {
		ID             string    `json:"id"`
		Timestamp      time.Time `json:"timestamp"`
		Service        string    `json:"service"`
		Category       string    `json:"category"`
		FingerprintID  string    `json:"fingerprint_id"`
		Probability    float64   `json:"probability"`
		Severity       string    `json:"severity"`
		TimeToIncident string    `json:"time_to_incident"`
		Description    string    `json:"description"`
		Status         string    `json:"status"`
	}

	var predictions []predictionRow
	for rows.Next() {
		var p predictionRow
		if err := rows.Scan(&p.ID, &p.Timestamp, &p.Service, &p.Category,
			&p.FingerprintID, &p.Probability, &p.Severity,
			&p.TimeToIncident, &p.Description, &p.Status); err != nil {
			continue
		}
		predictions = append(predictions, p)
	}

	c.JSON(http.StatusOK, gin.H{
		"predictions": predictions,
		"since":       since.Format(time.RFC3339),
		"count":       len(predictions),
	})
}

// handleGetServiceFeatures returns the latest computed features for a service.
func (s *Server) handleGetServiceFeatures(c *gin.Context) {
	service := c.Param("service")
	window := c.DefaultQuery("window", "5m")
	since := parseSince(c, 1*time.Hour)

	rows, err := s.chStore.Query(c.Request.Context(), `
		SELECT timestamp, name, value, window
		FROM computed_features
		WHERE service = $1 AND window = $2 AND timestamp >= $3
		ORDER BY timestamp DESC
		LIMIT 100
	`, service, window, since)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to query features"})
		return
	}
	defer rows.Close()

	type featureRow struct {
		Timestamp time.Time `json:"timestamp"`
		Name      string    `json:"name"`
		Value     float64   `json:"value"`
		Window    string    `json:"window"`
	}

	var features []featureRow
	for rows.Next() {
		var f featureRow
		if err := rows.Scan(&f.Timestamp, &f.Name, &f.Value, &f.Window); err != nil {
			continue
		}
		features = append(features, f)
	}

	c.JSON(http.StatusOK, gin.H{
		"service":  service,
		"features": features,
		"window":   window,
		"count":    len(features),
	})
}

// handleGetFeatureHistory returns time-series history for a specific feature.
func (s *Server) handleGetFeatureHistory(c *gin.Context) {
	service := c.Param("service")
	name := c.Param("name")
	window := c.DefaultQuery("window", "5m")
	since := parseSince(c, 24*time.Hour)

	values, err := s.chStore.GetFeatureHistory(c.Request.Context(), service, name, window, since)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": fmt.Sprintf("failed to query history: %v", err)})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"service": service,
		"feature": name,
		"window":  window,
		"values":  values,
		"count":   len(values),
	})
}

// handleListFingerprints returns all registered incident fingerprints.
func (s *Server) handleListFingerprints(c *gin.Context) {
	if s.corr == nil {
		c.JSON(http.StatusOK, gin.H{"fingerprints": []string{}, "count": 0})
		return
	}

	fps := s.corr.Fingerprints()
	type fpResponse struct {
		ID                string   `json:"id"`
		Name              string   `json:"name"`
		Category          string   `json:"category"`
		Description       string   `json:"description"`
		RequiredSignals   int      `json:"required_signals"`
		OptionalSignals   int      `json:"optional_signals"`
		EstimatedLeadTime string   `json:"estimated_lead_time"`
		BaseSeverity      string   `json:"base_severity"`
	}

	var result []fpResponse
	for _, fp := range fps {
		result = append(result, fpResponse{
			ID:                fp.ID,
			Name:              fp.Name,
			Category:          fp.Category,
			Description:       fp.Description,
			RequiredSignals:   len(fp.RequiredSignals),
			OptionalSignals:   len(fp.OptionalSignals),
			EstimatedLeadTime: fp.EstimatedLeadTime,
			BaseSeverity:      fp.BaseSeverity,
		})
	}

	c.JSON(http.StatusOK, gin.H{
		"fingerprints": result,
		"count":        len(result),
	})
}

// handleListServices returns all known services.
func (s *Server) handleListServices(c *gin.Context) {
	services, err := s.chStore.GetKnownServices(c.Request.Context())
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to list services"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"services": services,
		"count":    len(services),
	})
}

// --- Helpers ---

func parseSince(c *gin.Context, defaultDuration time.Duration) time.Time {
	sinceStr := c.Query("since")
	if sinceStr != "" {
		if t, err := time.Parse(time.RFC3339, sinceStr); err == nil {
			return t
		}
		// Try parsing as a duration (e.g. "1h", "30m").
		if d, err := time.ParseDuration(sinceStr); err == nil {
			return time.Now().UTC().Add(-d)
		}
	}
	return time.Now().UTC().Add(-defaultDuration)
}

func parseLimit(c *gin.Context, defaultLimit int) int {
	limitStr := c.Query("limit")
	if limitStr != "" {
		if l, err := strconv.Atoi(limitStr); err == nil && l > 0 && l <= 1000 {
			return l
		}
	}
	return defaultLimit
}
