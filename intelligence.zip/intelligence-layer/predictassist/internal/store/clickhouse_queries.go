package store

import (
	"context"
	"fmt"
	"time"

	"github.com/harshitjindal/predictassist/internal/models"
)

// GetKnownServices returns a list of distinct service names from raw_traces.
func (s *ClickHouseStore) GetKnownServices(ctx context.Context) ([]string, error) {
	rows, err := s.conn.Query(ctx, `
		SELECT DISTINCT service FROM raw_traces
		WHERE timestamp > now() - INTERVAL 1 HOUR
		UNION DISTINCT
		SELECT DISTINCT service FROM raw_logs
		WHERE timestamp > now() - INTERVAL 1 HOUR
	`)
	if err != nil {
		return nil, fmt.Errorf("query known services: %w", err)
	}
	defer rows.Close()

	var services []string
	for rows.Next() {
		var svc string
		if err := rows.Scan(&svc); err != nil {
			return nil, fmt.Errorf("scan service: %w", err)
		}
		services = append(services, svc)
	}
	return services, nil
}

// CountLogs counts total log records for a service in a time range.
func (s *ClickHouseStore) CountLogs(ctx context.Context, service string, start, end time.Time) (int64, error) {
	var count uint64
	err := s.conn.QueryRow(ctx, `
		SELECT count() FROM raw_logs
		WHERE service = $1 AND timestamp >= $2 AND timestamp < $3
	`, service, start, end).Scan(&count)
	if err != nil {
		return 0, fmt.Errorf("count logs: %w", err)
	}
	return int64(count), nil
}

// CountLogsBySeverity counts log records of a specific severity for a service.
func (s *ClickHouseStore) CountLogsBySeverity(ctx context.Context, service, severity string, start, end time.Time) (int64, error) {
	var count uint64
	err := s.conn.QueryRow(ctx, `
		SELECT count() FROM raw_logs
		WHERE service = $1 AND severity = $2 AND timestamp >= $3 AND timestamp < $4
	`, service, severity, start, end).Scan(&count)
	if err != nil {
		return 0, fmt.Errorf("count logs by severity: %w", err)
	}
	return int64(count), nil
}

// CountLogsBySeverityAll returns a map of severity → count for a service.
func (s *ClickHouseStore) CountLogsBySeverityAll(ctx context.Context, service string, start, end time.Time) (map[string]int64, error) {
	rows, err := s.conn.Query(ctx, `
		SELECT severity, count() as cnt FROM raw_logs
		WHERE service = $1 AND timestamp >= $2 AND timestamp < $3
		GROUP BY severity
	`, service, start, end)
	if err != nil {
		return nil, fmt.Errorf("count logs by severity all: %w", err)
	}
	defer rows.Close()

	result := make(map[string]int64)
	for rows.Next() {
		var sev string
		var cnt uint64
		if err := rows.Scan(&sev, &cnt); err != nil {
			return nil, fmt.Errorf("scan severity count: %w", err)
		}
		result[sev] = int64(cnt)
	}
	return result, nil
}

// CountUniqueErrorMessages counts distinct error message prefixes.
func (s *ClickHouseStore) CountUniqueErrorMessages(ctx context.Context, service string, start, end time.Time) (int64, error) {
	var count uint64
	err := s.conn.QueryRow(ctx, `
		SELECT uniqExact(substring(body, 1, 100)) FROM raw_logs
		WHERE service = $1 AND severity = 'ERROR' AND timestamp >= $2 AND timestamp < $3
	`, service, start, end).Scan(&count)
	if err != nil {
		return 0, fmt.Errorf("count unique error messages: %w", err)
	}
	return int64(count), nil
}

// CountTraces counts total trace spans for a service in a time range.
func (s *ClickHouseStore) CountTraces(ctx context.Context, service string, start, end time.Time) (int64, error) {
	var count uint64
	err := s.conn.QueryRow(ctx, `
		SELECT count() FROM raw_traces
		WHERE service = $1 AND timestamp >= $2 AND timestamp < $3
	`, service, start, end).Scan(&count)
	if err != nil {
		return 0, fmt.Errorf("count traces: %w", err)
	}
	return int64(count), nil
}

// CountErrorTraces counts trace spans with error status.
func (s *ClickHouseStore) CountErrorTraces(ctx context.Context, service string, start, end time.Time) (int64, error) {
	var count uint64
	err := s.conn.QueryRow(ctx, `
		SELECT count() FROM raw_traces
		WHERE service = $1 AND status = 'STATUS_CODE_ERROR' AND timestamp >= $2 AND timestamp < $3
	`, service, start, end).Scan(&count)
	if err != nil {
		return 0, fmt.Errorf("count error traces: %w", err)
	}
	return int64(count), nil
}

// LatencyPercentile computes a latency percentile from trace span durations.
func (s *ClickHouseStore) LatencyPercentile(ctx context.Context, service string, percentile float64, start, end time.Time) (float64, error) {
	var val float64
	err := s.conn.QueryRow(ctx, fmt.Sprintf(`
		SELECT quantile(%f)(duration_ns / 1000000.0) FROM raw_traces
		WHERE service = $1 AND timestamp >= $2 AND timestamp < $3
	`, percentile/100.0), service, start, end).Scan(&val)
	if err != nil {
		return 0, fmt.Errorf("latency percentile: %w", err)
	}
	return val, nil
}

// LatencyAvg computes the average span duration in milliseconds.
func (s *ClickHouseStore) LatencyAvg(ctx context.Context, service string, start, end time.Time) (float64, error) {
	var val float64
	err := s.conn.QueryRow(ctx, `
		SELECT avg(duration_ns / 1000000.0) FROM raw_traces
		WHERE service = $1 AND timestamp >= $2 AND timestamp < $3
	`, service, start, end).Scan(&val)
	if err != nil {
		return 0, fmt.Errorf("latency avg: %w", err)
	}
	return val, nil
}

// InsertComputedFeatures batch-inserts computed features.
func (s *ClickHouseStore) InsertComputedFeatures(ctx context.Context, features []models.ComputedFeature) error {
	if len(features) == 0 {
		return nil
	}

	batch, err := s.conn.PrepareBatch(ctx, `
		INSERT INTO computed_features (timestamp, service, name, value, window)
	`)
	if err != nil {
		return fmt.Errorf("prepare features batch: %w", err)
	}

	for _, f := range features {
		if err := batch.Append(f.Timestamp, f.Service, f.Name, f.Value, f.Window); err != nil {
			return fmt.Errorf("append feature: %w", err)
		}
	}

	return batch.Send()
}

// GetFeatureHistory returns historical feature values for baseline computation.
func (s *ClickHouseStore) GetFeatureHistory(ctx context.Context, service, featureName, window string, since time.Time) ([]float64, error) {
	rows, err := s.conn.Query(ctx, `
		SELECT value FROM computed_features
		WHERE service = $1 AND name = $2 AND window = $3 AND timestamp >= $4
		ORDER BY timestamp ASC
	`, service, featureName, window, since)
	if err != nil {
		return nil, fmt.Errorf("query feature history: %w", err)
	}
	defer rows.Close()

	var values []float64
	for rows.Next() {
		var v float64
		if err := rows.Scan(&v); err != nil {
			return nil, fmt.Errorf("scan feature value: %w", err)
		}
		values = append(values, v)
	}
	return values, nil
}

// InsertAnomalyRecords batch-inserts anomaly detection records.
func (s *ClickHouseStore) InsertAnomalyRecords(ctx context.Context, records []models.AnomalyRecord) error {
	if len(records) == 0 {
		return nil
	}

	batch, err := s.conn.PrepareBatch(ctx, `
		INSERT INTO anomaly_events (
			id, timestamp, service, severity, feature_name,
			value, baseline, z_score, std_dev, window, description
		)
	`)
	if err != nil {
		return fmt.Errorf("prepare anomaly batch: %w", err)
	}

	for _, r := range records {
		if err := batch.Append(
			r.ID, r.Timestamp, r.Service, r.Severity,
			r.FeatureName, r.Value, r.Baseline, r.ZScore,
			r.StdDev, r.Window, r.Description,
		); err != nil {
			return fmt.Errorf("append anomaly record: %w", err)
		}
	}

	return batch.Send()
}

// QueryRecentAnomalies returns recent anomaly records for a service.
func (s *ClickHouseStore) QueryRecentAnomalies(ctx context.Context, service string, since time.Time, limit int) ([]models.AnomalyRecord, error) {
	rows, err := s.conn.Query(ctx, `
		SELECT id, timestamp, service, severity, feature_name,
			   value, baseline, z_score, std_dev, window, description
		FROM anomaly_events
		WHERE service = $1 AND timestamp >= $2
		ORDER BY timestamp DESC
		LIMIT $3
	`, service, since, limit)
	if err != nil {
		return nil, fmt.Errorf("query recent anomalies: %w", err)
	}
	defer rows.Close()

	var records []models.AnomalyRecord
	for rows.Next() {
		var r models.AnomalyRecord
		if err := rows.Scan(
			&r.ID, &r.Timestamp, &r.Service, &r.Severity,
			&r.FeatureName, &r.Value, &r.Baseline, &r.ZScore,
			&r.StdDev, &r.Window, &r.Description,
		); err != nil {
			return nil, fmt.Errorf("scan anomaly record: %w", err)
		}
		records = append(records, r)
	}
	return records, nil
}
