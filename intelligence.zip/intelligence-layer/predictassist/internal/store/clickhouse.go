// Package store provides storage backends for PredictAssist telemetry data.
// The primary store is ClickHouse for analytical queries, supplemented by
// Redis for hot caching of computed features and baselines.
package store

import (
	"context"
	"embed"
	"fmt"
	"log"
	"sort"
	"strings"

	"github.com/ClickHouse/clickhouse-go/v2/lib/driver"
	"github.com/harshitjindal/predictassist/internal/models"
)

//go:embed migrations/*.sql
var migrationFS embed.FS

// ClickHouseStore wraps a ClickHouse connection and provides typed insert
// methods for each telemetry signal. All writes use batch inserts for
// throughput.
type ClickHouseStore struct {
	conn driver.Conn
}

// NewClickHouseStore creates a new store backed by the given ClickHouse connection.
func NewClickHouseStore(conn driver.Conn) *ClickHouseStore {
	return &ClickHouseStore{conn: conn}
}

// RunMigrations executes all embedded SQL migration files in lexicographic
// order. Each file should be idempotent (use IF NOT EXISTS).
func (s *ClickHouseStore) RunMigrations(ctx context.Context) error {
	entries, err := migrationFS.ReadDir("migrations")
	if err != nil {
		return fmt.Errorf("reading migrations dir: %w", err)
	}

	// Sort entries by name to guarantee execution order.
	sort.Slice(entries, func(i, j int) bool {
		return entries[i].Name() < entries[j].Name()
	})

	for _, entry := range entries {
		if entry.IsDir() || !strings.HasSuffix(entry.Name(), ".sql") {
			continue
		}

		data, err := migrationFS.ReadFile("migrations/" + entry.Name())
		if err != nil {
			return fmt.Errorf("reading migration %s: %w", entry.Name(), err)
		}

		// Split on semicolons to support multi-statement migration files.
		stmts := strings.Split(string(data), ";")
		for _, stmt := range stmts {
			stmt = strings.TrimSpace(stmt)
			if stmt == "" {
				continue
			}
			if err := s.conn.Exec(ctx, stmt); err != nil {
				return fmt.Errorf("executing migration %s: %w", entry.Name(), err)
			}
		}

		log.Printf("store: applied migration %s", entry.Name())
	}

	return nil
}

// InsertLogs batch-inserts log records into the raw_logs table.
func (s *ClickHouseStore) InsertLogs(ctx context.Context, records []models.LogRecord) error {
	if len(records) == 0 {
		return nil
	}

	batch, err := s.conn.PrepareBatch(ctx, `
		INSERT INTO raw_logs (
			timestamp, service, severity, body,
			attributes, resource_attributes,
			trace_id, span_id
		)
	`)
	if err != nil {
		return fmt.Errorf("prepare logs batch: %w", err)
	}

	for _, r := range records {
		if err := batch.Append(
			r.Timestamp,
			r.Service,
			r.Severity,
			r.Body,
			r.Attributes,
			r.ResourceAttributes,
			r.TraceID,
			r.SpanID,
		); err != nil {
			return fmt.Errorf("append log record: %w", err)
		}
	}

	if err := batch.Send(); err != nil {
		return fmt.Errorf("send logs batch: %w", err)
	}

	return nil
}

// InsertMetrics batch-inserts metric records into the raw_metrics table.
func (s *ClickHouseStore) InsertMetrics(ctx context.Context, records []models.MetricRecord) error {
	if len(records) == 0 {
		return nil
	}

	batch, err := s.conn.PrepareBatch(ctx, `
		INSERT INTO raw_metrics (
			timestamp, service, name, value,
			metric_type, attributes, resource_attributes
		)
	`)
	if err != nil {
		return fmt.Errorf("prepare metrics batch: %w", err)
	}

	for _, r := range records {
		if err := batch.Append(
			r.Timestamp,
			r.Service,
			r.Name,
			r.Value,
			r.MetricType,
			r.Attributes,
			r.ResourceAttributes,
		); err != nil {
			return fmt.Errorf("append metric record: %w", err)
		}
	}

	if err := batch.Send(); err != nil {
		return fmt.Errorf("send metrics batch: %w", err)
	}

	return nil
}

// InsertTraces batch-inserts trace spans into the raw_traces table.
func (s *ClickHouseStore) InsertTraces(ctx context.Context, spans []models.TraceSpan) error {
	if len(spans) == 0 {
		return nil
	}

	batch, err := s.conn.PrepareBatch(ctx, `
		INSERT INTO raw_traces (
			timestamp, service, trace_id, span_id,
			parent_span_id, operation, duration_ns,
			status, attributes, resource_attributes
		)
	`)
	if err != nil {
		return fmt.Errorf("prepare traces batch: %w", err)
	}

	for _, sp := range spans {
		if err := batch.Append(
			sp.Timestamp,
			sp.Service,
			sp.TraceID,
			sp.SpanID,
			sp.ParentSpanID,
			sp.Operation,
			sp.DurationNs,
			sp.Status,
			sp.Attributes,
			sp.ResourceAttributes,
		); err != nil {
			return fmt.Errorf("append trace span: %w", err)
		}
	}

	if err := batch.Send(); err != nil {
		return fmt.Errorf("send traces batch: %w", err)
	}

	return nil
}

// Close closes the underlying ClickHouse connection.
func (s *ClickHouseStore) Close() error {
	return s.conn.Close()
}

// Query executes a raw query and returns the Rows interface for scanning.
// Callers are responsible for closing the returned rows.
func (s *ClickHouseStore) Query(ctx context.Context, query string, args ...any) (driver.Rows, error) {
	return s.conn.Query(ctx, query, args...)
}

// Exec executes a statement that does not return rows.
func (s *ClickHouseStore) Exec(ctx context.Context, query string, args ...any) error {
	return s.conn.Exec(ctx, query, args...)
}
