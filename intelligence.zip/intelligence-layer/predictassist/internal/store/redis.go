package store

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/redis/go-redis/v9"
)

// RedisStore wraps a Redis client and provides typed get/set helpers for
// caching computed features and baseline statistics.
type RedisStore struct {
	client *redis.Client
}

// NewRedisStore creates a new RedisStore backed by the given client.
func NewRedisStore(client *redis.Client) *RedisStore {
	return &RedisStore{client: client}
}

// FeatureValue represents a cached computed feature.
type FeatureValue struct {
	Service   string    `json:"service"`
	Name      string    `json:"name"`
	Value     float64   `json:"value"`
	Window    string    `json:"window"`
	Timestamp time.Time `json:"timestamp"`
}

// BaselineStats represents cached baseline statistics for a feature.
type BaselineStats struct {
	Service  string  `json:"service"`
	Name     string  `json:"name"`
	Mean     float64 `json:"mean"`
	StdDev   float64 `json:"std_dev"`
	P50      float64 `json:"p50"`
	P95      float64 `json:"p95"`
	P99      float64 `json:"p99"`
	Count    int64   `json:"count"`
	Window   string  `json:"window"`
}

// featureKey returns the Redis key for a computed feature value.
func featureKey(service, name, window string) string {
	return fmt.Sprintf("feature:%s:%s:%s", service, name, window)
}

// baselineKey returns the Redis key for baseline statistics.
func baselineKey(service, name string) string {
	return fmt.Sprintf("baseline:%s:%s", service, name)
}

// anomalyKey returns the Redis key for active anomalies.
func anomalyKey(service string) string {
	return fmt.Sprintf("anomaly:active:%s", service)
}

// SetFeature caches a computed feature value with a TTL.
func (s *RedisStore) SetFeature(ctx context.Context, fv FeatureValue, ttl time.Duration) error {
	data, err := json.Marshal(fv)
	if err != nil {
		return fmt.Errorf("marshal feature: %w", err)
	}
	key := featureKey(fv.Service, fv.Name, fv.Window)
	return s.client.Set(ctx, key, data, ttl).Err()
}

// GetFeature retrieves a cached feature value.
func (s *RedisStore) GetFeature(ctx context.Context, service, name, window string) (*FeatureValue, error) {
	key := featureKey(service, name, window)
	data, err := s.client.Get(ctx, key).Bytes()
	if err != nil {
		return nil, err
	}
	var fv FeatureValue
	if err := json.Unmarshal(data, &fv); err != nil {
		return nil, fmt.Errorf("unmarshal feature: %w", err)
	}
	return &fv, nil
}

// SetBaseline caches baseline statistics for a feature.
func (s *RedisStore) SetBaseline(ctx context.Context, bs BaselineStats, ttl time.Duration) error {
	data, err := json.Marshal(bs)
	if err != nil {
		return fmt.Errorf("marshal baseline: %w", err)
	}
	key := baselineKey(bs.Service, bs.Name)
	return s.client.Set(ctx, key, data, ttl).Err()
}

// GetBaseline retrieves cached baseline statistics.
func (s *RedisStore) GetBaseline(ctx context.Context, service, name string) (*BaselineStats, error) {
	key := baselineKey(service, name)
	data, err := s.client.Get(ctx, key).Bytes()
	if err != nil {
		return nil, err
	}
	var bs BaselineStats
	if err := json.Unmarshal(data, &bs); err != nil {
		return nil, fmt.Errorf("unmarshal baseline: %w", err)
	}
	return &bs, nil
}

// SetActiveAnomaly stores an active anomaly ID for a service.
func (s *RedisStore) SetActiveAnomaly(ctx context.Context, service, anomalyID string, ttl time.Duration) error {
	key := anomalyKey(service)
	return s.client.SAdd(ctx, key, anomalyID).Err()
}

// GetActiveAnomalies returns all active anomaly IDs for a service.
func (s *RedisStore) GetActiveAnomalies(ctx context.Context, service string) ([]string, error) {
	key := anomalyKey(service)
	return s.client.SMembers(ctx, key).Result()
}

// RemoveActiveAnomaly removes an anomaly ID from the active set.
func (s *RedisStore) RemoveActiveAnomaly(ctx context.Context, service, anomalyID string) error {
	key := anomalyKey(service)
	return s.client.SRem(ctx, key, anomalyID).Err()
}

// Close closes the underlying Redis client.
func (s *RedisStore) Close() error {
	return s.client.Close()
}
