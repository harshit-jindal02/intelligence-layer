-- ClickHouse migration: anomaly_events table
-- Stores detected anomalies with their statistical evidence.

CREATE TABLE IF NOT EXISTS anomaly_events (
    id          String,
    timestamp   DateTime64(9, 'UTC'),
    service     LowCardinality(String),
    severity    LowCardinality(String),
    feature_name LowCardinality(String),
    value       Float64,
    baseline    Float64,
    z_score     Float64,
    std_dev     Float64,
    window      LowCardinality(String),
    description String DEFAULT ''
)
ENGINE = MergeTree()
PARTITION BY toYYYYMMDD(timestamp)
ORDER BY (service, timestamp)
TTL toDateTime(timestamp) + INTERVAL 90 DAY
SETTINGS index_granularity = 8192
