-- ClickHouse migration: raw_logs table
-- Stores ingested log records from OTLP sources.

CREATE TABLE IF NOT EXISTS raw_logs (
    timestamp       DateTime64(9, 'UTC'),
    service         LowCardinality(String),
    severity        LowCardinality(String),
    body            String,
    attributes      Map(String, String),
    resource_attributes Map(String, String),
    trace_id        String DEFAULT '',
    span_id         String DEFAULT ''
)
ENGINE = MergeTree()
PARTITION BY toYYYYMMDD(timestamp)
ORDER BY (service, timestamp)
TTL toDateTime(timestamp) + INTERVAL 30 DAY
SETTINGS index_granularity = 8192
