-- Migration: 006 - Incident Predictions table
-- Stores generated incident predictions for API queries and historical analysis.

CREATE TABLE IF NOT EXISTS incident_predictions (
    id              String,
    timestamp       DateTime64(3, 'UTC'),
    service         String,
    category        String,
    fingerprint_id  String,
    probability     Float64,
    severity        LowCardinality(String),
    time_to_incident String,
    anomaly_ids     Array(String),
    affected_services Array(String),
    description     String DEFAULT '',
    status          LowCardinality(String) DEFAULT 'active'
) ENGINE = MergeTree()
PARTITION BY toYYYYMMDD(timestamp)
ORDER BY (service, category, timestamp)
TTL toDateTime(timestamp) + INTERVAL 90 DAY;
