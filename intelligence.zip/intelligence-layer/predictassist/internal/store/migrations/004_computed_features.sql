-- ClickHouse migration: computed_features table
-- Stores feature values computed by the feature engine.

CREATE TABLE IF NOT EXISTS computed_features (
    timestamp   DateTime64(9, 'UTC'),
    service     LowCardinality(String),
    name        LowCardinality(String),
    value       Float64,
    window      LowCardinality(String)
)
ENGINE = MergeTree()
PARTITION BY toYYYYMMDD(timestamp)
ORDER BY (service, name, window, timestamp)
TTL toDateTime(timestamp) + INTERVAL 30 DAY
SETTINGS index_granularity = 8192
