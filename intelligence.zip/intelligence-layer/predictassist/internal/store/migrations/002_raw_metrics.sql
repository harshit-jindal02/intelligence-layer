-- ClickHouse migration: raw_metrics table
-- Stores ingested metric data points from OTLP sources.

CREATE TABLE IF NOT EXISTS raw_metrics (
    timestamp       DateTime64(9, 'UTC'),
    service         LowCardinality(String),
    name            LowCardinality(String),
    value           Float64,
    metric_type     LowCardinality(String),
    attributes      Map(String, String),
    resource_attributes Map(String, String)
)
ENGINE = MergeTree()
PARTITION BY toYYYYMMDD(timestamp)
ORDER BY (service, name, timestamp)
TTL toDateTime(timestamp) + INTERVAL 30 DAY
SETTINGS index_granularity = 8192
