-- ClickHouse migration: raw_traces table
-- Stores ingested trace spans from OTLP sources.

CREATE TABLE IF NOT EXISTS raw_traces (
    timestamp       DateTime64(9, 'UTC'),
    service         LowCardinality(String),
    trace_id        String,
    span_id         String,
    parent_span_id  String DEFAULT '',
    operation       LowCardinality(String),
    duration_ns     Int64,
    status          LowCardinality(String),
    attributes      Map(String, String),
    resource_attributes Map(String, String)
)
ENGINE = MergeTree()
PARTITION BY toYYYYMMDD(timestamp)
ORDER BY (service, trace_id, timestamp)
TTL toDateTime(timestamp) + INTERVAL 30 DAY
SETTINGS index_granularity = 8192
