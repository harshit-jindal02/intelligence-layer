// Package detector provides anomaly detection algorithms that evaluate
// computed features against statistical baselines to identify anomalous
// service behaviour.
package detector

import (
	"context"
	"fmt"
	"log"
	"sync"
	"time"

	"github.com/google/uuid"
	"github.com/harshitjindal/predictassist/internal/events"
	"github.com/harshitjindal/predictassist/internal/models"
	"github.com/harshitjindal/predictassist/internal/store"
)

// Detector is the interface all anomaly detection algorithms implement.
type Detector interface {
	// Name returns the detector identifier.
	Name() string

	// Detect evaluates feature history and current value to determine
	// if an anomaly exists. Returns nil if no anomaly.
	Detect(ctx context.Context, input DetectInput) (*DetectResult, error)
}

// DetectInput provides context for anomaly detection.
type DetectInput struct {
	Service     string
	FeatureName string
	Window      string
	Current     float64
	History     []float64 // historical values, oldest first
}

// DetectResult describes a detected anomaly.
type DetectResult struct {
	Severity    string
	ZScore      float64
	Baseline    float64
	StdDev      float64
	Description string
}

// Engine coordinates anomaly detection across all services and features.
type Engine struct {
	chStore    *store.ClickHouseStore
	redisStore *store.RedisStore
	eventBus   *events.EventBus
	detectors  []Detector
	cfg        EngineConfig

	mu      sync.Mutex
	started bool
}

// EngineConfig holds configuration for the detection engine.
type EngineConfig struct {
	// EvalInterval is how often the engine runs detection.
	EvalInterval time.Duration

	// BaselineWindow is how far back to look for baseline data.
	BaselineWindow time.Duration

	// MinDataPoints is the minimum number of data points needed before
	// detection is performed (avoids false positives during cold start).
	MinDataPoints int

	// Cooldown prevents the same anomaly from being re-reported within
	// this duration.
	Cooldown time.Duration

	// Windows are the feature window sizes to evaluate.
	Windows []string
}

// NewEngine creates a new detection engine.
func NewEngine(ch *store.ClickHouseStore, redis *store.RedisStore, bus *events.EventBus, cfg EngineConfig) *Engine {
	if cfg.EvalInterval == 0 {
		cfg.EvalInterval = 15 * time.Second
	}
	if cfg.BaselineWindow == 0 {
		cfg.BaselineWindow = 1 * time.Hour
	}
	if cfg.MinDataPoints == 0 {
		cfg.MinDataPoints = 30
	}
	if cfg.Cooldown == 0 {
		cfg.Cooldown = 5 * time.Minute
	}
	if len(cfg.Windows) == 0 {
		cfg.Windows = []string{"1m0s", "5m0s", "15m0s"}
	}

	return &Engine{
		chStore:    ch,
		redisStore: redis,
		eventBus:   bus,
		cfg:        cfg,
		detectors: []Detector{
			NewZScoreDetector(3.0),
			NewIQRDetector(1.5),
		},
	}
}

// Run starts the detection evaluation loop. It blocks until ctx is cancelled.
func (e *Engine) Run(ctx context.Context) {
	e.mu.Lock()
	if e.started {
		e.mu.Unlock()
		return
	}
	e.started = true
	e.mu.Unlock()

	log.Printf("detector engine: started (interval=%s, baseline=%s, min_points=%d)",
		e.cfg.EvalInterval, e.cfg.BaselineWindow, e.cfg.MinDataPoints)

	ticker := time.NewTicker(e.cfg.EvalInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			log.Printf("detector engine: stopped")
			return
		case <-ticker.C:
			e.evaluateAll(ctx)
		}
	}
}

// evaluateAll runs detection for all services, features, and windows.
func (e *Engine) evaluateAll(ctx context.Context) {
	services, err := e.chStore.GetKnownServices(ctx)
	if err != nil {
		log.Printf("detector engine: failed to get services: %v", err)
		return
	}

	featureNames := []string{
		"error_rate", "request_rate", "log_volume",
		"latency_p50", "latency_p95", "latency_p99", "latency_avg",
		"error_to_total_ratio", "warn_to_info_ratio",
		"error_rate_delta", "latency_delta",
		"unique_error_types", "log_entropy",
	}

	var anomalies []models.AnomalyRecord

	for _, svc := range services {
		for _, window := range e.cfg.Windows {
			for _, feat := range featureNames {
				results := e.evaluate(ctx, svc, feat, window)
				anomalies = append(anomalies, results...)
			}
		}
	}

	if len(anomalies) > 0 {
		if err := e.chStore.InsertAnomalyRecords(ctx, anomalies); err != nil {
			log.Printf("detector engine: failed to write anomalies: %v", err)
		}

		// Publish anomaly events to NATS.
		for _, a := range anomalies {
			e.publishAnomaly(ctx, a)
		}

		log.Printf("detector engine: detected %d anomalies", len(anomalies))
	}
}

// evaluate runs all detectors for a single feature.
func (e *Engine) evaluate(ctx context.Context, service, featureName, window string) []models.AnomalyRecord {
	since := time.Now().UTC().Add(-e.cfg.BaselineWindow)
	history, err := e.chStore.GetFeatureHistory(ctx, service, featureName, window, since)
	if err != nil || len(history) < e.cfg.MinDataPoints {
		return nil
	}

	current := history[len(history)-1]
	baseline := history[:len(history)-1]

	var anomalies []models.AnomalyRecord

	for _, det := range e.detectors {
		result, err := det.Detect(ctx, DetectInput{
			Service:     service,
			FeatureName: featureName,
			Window:      window,
			Current:     current,
			History:     baseline,
		})
		if err != nil {
			log.Printf("detector engine: %s/%s/%s %s error: %v", service, featureName, window, det.Name(), err)
			continue
		}
		if result == nil {
			continue
		}

		anomalies = append(anomalies, models.AnomalyRecord{
			ID:          uuid.New().String(),
			Timestamp:   time.Now().UTC(),
			Service:     service,
			Severity:    result.Severity,
			FeatureName: featureName,
			Value:       current,
			Baseline:    result.Baseline,
			ZScore:      result.ZScore,
			StdDev:      result.StdDev,
			Window:      window,
			Description: fmt.Sprintf("[%s] %s", det.Name(), result.Description),
		})
	}

	return anomalies
}

// publishAnomaly sends an anomaly event to the NATS event bus.
func (e *Engine) publishAnomaly(ctx context.Context, a models.AnomalyRecord) {
	if e.eventBus == nil {
		return
	}
	event, err := events.NewEvent(a.ID, events.SubjectAnomalyDetected, "detector", a)
	if err != nil {
		log.Printf("detector engine: failed to create event: %v", err)
		return
	}
	if err := e.eventBus.Publish(ctx, events.SubjectAnomalyDetected, event); err != nil {
		log.Printf("detector engine: failed to publish event: %v", err)
	}
}
