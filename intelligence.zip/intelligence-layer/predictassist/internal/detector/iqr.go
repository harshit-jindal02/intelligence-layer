package detector

import (
	"context"
	"fmt"
	"math"
	"sort"
)

// IQRDetector uses the Interquartile Range method to detect outliers.
// It is robust to skewed distributions, unlike the Z-score method.
type IQRDetector struct {
	multiplier float64 // typically 1.5 for outliers, 3.0 for extreme outliers
}

// NewIQRDetector creates an IQR-based outlier detector.
func NewIQRDetector(multiplier float64) *IQRDetector {
	return &IQRDetector{multiplier: multiplier}
}

func (d *IQRDetector) Name() string { return "iqr" }

func (d *IQRDetector) Detect(_ context.Context, input DetectInput) (*DetectResult, error) {
	if len(input.History) < 4 {
		return nil, nil
	}

	sorted := make([]float64, len(input.History))
	copy(sorted, input.History)
	sort.Float64s(sorted)

	q1 := percentile(sorted, 25)
	q3 := percentile(sorted, 75)
	iqr := q3 - q1

	if iqr == 0 {
		return nil, nil
	}

	lowerBound := q1 - d.multiplier*iqr
	upperBound := q3 + d.multiplier*iqr

	if input.Current >= lowerBound && input.Current <= upperBound {
		return nil, nil
	}

	// Compute a pseudo z-score for severity classification.
	mean, stdDev := meanStdDev(input.History)
	var zScore float64
	if stdDev > 0 {
		zScore = (input.Current - mean) / stdDev
	}

	return &DetectResult{
		Severity:    severityFromZScore(math.Abs(zScore)),
		ZScore:      zScore,
		Baseline:    mean,
		StdDev:      stdDev,
		Description: fmt.Sprintf("%s=%.4f outside IQR bounds [%.4f, %.4f]", input.FeatureName, input.Current, lowerBound, upperBound),
	}, nil
}

// percentile calculates the p-th percentile of a sorted slice using linear interpolation.
func percentile(sorted []float64, p float64) float64 {
	if len(sorted) == 0 {
		return 0
	}
	if len(sorted) == 1 {
		return sorted[0]
	}

	rank := p / 100.0 * float64(len(sorted)-1)
	lower := int(math.Floor(rank))
	upper := lower + 1
	if upper >= len(sorted) {
		return sorted[len(sorted)-1]
	}

	weight := rank - float64(lower)
	return sorted[lower]*(1-weight) + sorted[upper]*weight
}
