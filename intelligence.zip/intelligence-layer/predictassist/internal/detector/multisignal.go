package detector

import (
	"context"
	"fmt"
	"log"
	"time"

	"github.com/google/uuid"
	"github.com/harshitjindal/predictassist/internal/events"
	"github.com/harshitjindal/predictassist/internal/models"
	"github.com/harshitjindal/predictassist/internal/store"
)

// MultiSignalDetector correlates anomalies across features and services
// to identify multi-dimensional anomaly patterns. A single metric spiking
// is often noise; three related metrics shifting together is a pattern.
type MultiSignalDetector struct {
	chStore  *store.ClickHouseStore
	eventBus *events.EventBus
	cfg      MultiSignalConfig
}

// MultiSignalConfig holds configuration for multi-signal correlation.
type MultiSignalConfig struct {
	// TimeWindow is how far back to look for correlated anomalies.
	TimeWindow time.Duration

	// MinSignals is the minimum number of correlated anomalies to report.
	MinSignals int

	// EvalInterval is how often multi-signal detection runs.
	EvalInterval time.Duration
}

// CorrelationGroup represents a set of correlated anomalies.
type CorrelationGroup struct {
	ID        string
	Service   string
	Anomalies []models.AnomalyRecord
	Severity  string
	CreatedAt time.Time
}

// NewMultiSignalDetector creates a multi-signal correlation detector.
func NewMultiSignalDetector(ch *store.ClickHouseStore, bus *events.EventBus, cfg MultiSignalConfig) *MultiSignalDetector {
	if cfg.TimeWindow == 0 {
		cfg.TimeWindow = 2 * time.Minute
	}
	if cfg.MinSignals == 0 {
		cfg.MinSignals = 2
	}
	if cfg.EvalInterval == 0 {
		cfg.EvalInterval = 30 * time.Second
	}
	return &MultiSignalDetector{chStore: ch, eventBus: bus, cfg: cfg}
}

// Run starts the multi-signal detection loop.
func (d *MultiSignalDetector) Run(ctx context.Context) {
	log.Printf("multisignal detector: started (window=%s, min_signals=%d)", d.cfg.TimeWindow, d.cfg.MinSignals)

	ticker := time.NewTicker(d.cfg.EvalInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			log.Printf("multisignal detector: stopped")
			return
		case <-ticker.C:
			d.evaluate(ctx)
		}
	}
}

// evaluate looks for correlated anomalies across services.
func (d *MultiSignalDetector) evaluate(ctx context.Context) {
	services, err := d.chStore.GetKnownServices(ctx)
	if err != nil {
		return
	}

	since := time.Now().UTC().Add(-d.cfg.TimeWindow)

	for _, svc := range services {
		anomalies, err := d.chStore.QueryRecentAnomalies(ctx, svc, since, 100)
		if err != nil || len(anomalies) < d.cfg.MinSignals {
			continue
		}

		// Group anomalies by feature to check for multi-feature correlation.
		featureMap := make(map[string][]models.AnomalyRecord)
		for _, a := range anomalies {
			featureMap[a.FeatureName] = append(featureMap[a.FeatureName], a)
		}

		if len(featureMap) < d.cfg.MinSignals {
			continue
		}

		group := CorrelationGroup{
			ID:        uuid.New().String(),
			Service:   svc,
			Anomalies: anomalies,
			Severity:  highestSeverity(anomalies),
			CreatedAt: time.Now().UTC(),
		}

		d.publishCorrelation(ctx, group)
	}
}

func highestSeverity(anomalies []models.AnomalyRecord) string {
	priority := map[string]int{"low": 0, "medium": 1, "high": 2, "critical": 3}
	best := "low"
	for _, a := range anomalies {
		if priority[a.Severity] > priority[best] {
			best = a.Severity
		}
	}
	return best
}

func (d *MultiSignalDetector) publishCorrelation(ctx context.Context, group CorrelationGroup) {
	if d.eventBus == nil {
		return
	}

	event, err := events.NewEvent(group.ID, events.SubjectCorrelationGroup, "multisignal", map[string]interface{}{
		"service":       group.Service,
		"severity":      group.Severity,
		"anomaly_count": len(group.Anomalies),
		"features":      featureNames(group.Anomalies),
	})
	if err != nil {
		log.Printf("multisignal: failed to create event: %v", err)
		return
	}
	if err := d.eventBus.Publish(ctx, events.SubjectCorrelationGroup, event); err != nil {
		log.Printf("multisignal: failed to publish: %v", err)
	}

	log.Printf("multisignal: correlated %d anomalies for %s (severity=%s, features=%v)",
		len(group.Anomalies), group.Service, group.Severity,
		featureNames(group.Anomalies))
}

func featureNames(anomalies []models.AnomalyRecord) []string {
	seen := make(map[string]bool)
	var names []string
	for _, a := range anomalies {
		if !seen[a.FeatureName] {
			seen[a.FeatureName] = true
			names = append(names, a.FeatureName)
		}
	}
	return names
}

// crossServiceCorrelation detects when the same anomaly type appears
// across multiple services simultaneously (e.g., cascade failures).
func (d *MultiSignalDetector) crossServiceCorrelation(ctx context.Context) {
	since := time.Now().UTC().Add(-d.cfg.TimeWindow)
	services, err := d.chStore.GetKnownServices(ctx)
	if err != nil || len(services) < 2 {
		return
	}

	// Collect all anomalies across services.
	allAnomalies := make(map[string][]models.AnomalyRecord)
	for _, svc := range services {
		anomalies, err := d.chStore.QueryRecentAnomalies(ctx, svc, since, 50)
		if err != nil || len(anomalies) == 0 {
			continue
		}
		allAnomalies[svc] = anomalies
	}

	// Look for the same feature anomaly in multiple services.
	featureToServices := make(map[string][]string)
	for svc, anomalies := range allAnomalies {
		for _, a := range anomalies {
			featureToServices[a.FeatureName] = append(featureToServices[a.FeatureName], svc)
		}
	}

	for feat, svcs := range featureToServices {
		unique := uniqueStrings(svcs)
		if len(unique) >= 2 {
			log.Printf("multisignal: cross-service anomaly detected: %s in services %v", feat, unique)

			if d.eventBus != nil {
				event, _ := events.NewEvent(
					uuid.New().String(),
					events.SubjectCorrelationGroup,
					"multisignal-cross",
					map[string]interface{}{
						"type":     "cross_service",
						"feature":  feat,
						"services": unique,
					},
				)
				_ = d.eventBus.Publish(ctx, events.SubjectCorrelationGroup, event)
			}
		}
	}
}

func uniqueStrings(ss []string) []string {
	seen := make(map[string]bool)
	var result []string
	for _, s := range ss {
		if !seen[s] {
			seen[s] = true
			result = append(result, s)
		}
	}
	return result
}

// ensure crossServiceCorrelation has no unused variable warning
var _ = fmt.Sprintf
