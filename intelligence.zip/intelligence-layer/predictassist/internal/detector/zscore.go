package detector

import (
	"context"
	"fmt"
	"math"
)

// ZScoreDetector flags features that deviate more than a configurable number
// of standard deviations from the rolling mean of the baseline window.
type ZScoreDetector struct {
	threshold float64
}

// NewZScoreDetector creates a Z-score detector with the given threshold.
func NewZScoreDetector(threshold float64) *ZScoreDetector {
	return &ZScoreDetector{threshold: threshold}
}

func (d *ZScoreDetector) Name() string { return "zscore" }

func (d *ZScoreDetector) Detect(_ context.Context, input DetectInput) (*DetectResult, error) {
	if len(input.History) < 2 {
		return nil, nil
	}

	mean, stdDev := meanStdDev(input.History)
	if stdDev == 0 {
		// No variance — can't compute z-score. If current differs from
		// constant baseline, flag it.
		if input.Current != mean {
			return &DetectResult{
				Severity:    severityFromZScore(10), // arbitrary high z-score
				ZScore:      10,
				Baseline:    mean,
				StdDev:      0,
				Description: fmt.Sprintf("%s=%.4f deviates from constant baseline %.4f", input.FeatureName, input.Current, mean),
			}, nil
		}
		return nil, nil
	}

	zScore := (input.Current - mean) / stdDev
	absZ := math.Abs(zScore)

	if absZ < d.threshold {
		return nil, nil
	}

	return &DetectResult{
		Severity:    severityFromZScore(absZ),
		ZScore:      zScore,
		Baseline:    mean,
		StdDev:      stdDev,
		Description: fmt.Sprintf("%s=%.4f (z=%.2f, mean=%.4f, stddev=%.4f)", input.FeatureName, input.Current, zScore, mean, stdDev),
	}, nil
}

func meanStdDev(values []float64) (float64, float64) {
	n := float64(len(values))
	if n == 0 {
		return 0, 0
	}

	var sum float64
	for _, v := range values {
		sum += v
	}
	mean := sum / n

	var sumSqDiff float64
	for _, v := range values {
		diff := v - mean
		sumSqDiff += diff * diff
	}

	stdDev := math.Sqrt(sumSqDiff / n)
	return mean, stdDev
}

func severityFromZScore(absZ float64) string {
	switch {
	case absZ >= 5:
		return "critical"
	case absZ >= 4:
		return "high"
	case absZ >= 3:
		return "medium"
	default:
		return "low"
	}
}
