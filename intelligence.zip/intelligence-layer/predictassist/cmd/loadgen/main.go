// Command loadgen generates realistic traffic against ShopSim to build
// a behavioral baseline for PredictAssist's anomaly detection. It simulates
// user journeys: creating users, browsing products, placing orders.
package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"math/rand"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
)

func envOrDefault(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func envOrDefaultInt(key string, fallback int) int {
	if v := os.Getenv(key); v != "" {
		n, err := strconv.Atoi(v)
		if err == nil {
			return n
		}
	}
	return fallback
}

// stats tracks request counters for periodic reporting.
type stats struct {
	requests  atomic.Int64
	errors    atomic.Int64
	userIDs   atomic.Int64
	productIDs atomic.Int64
}

func main() {
	targetURL := envOrDefault("TARGET_URL", "http://localhost:8080")
	concurrency := envOrDefaultInt("CONCURRENCY", 5)
	rps := envOrDefaultInt("RPS", 10)

	log.Printf("loadgen: target=%s concurrency=%d rps=%d", targetURL, concurrency, rps)

	client := &http.Client{Timeout: 10 * time.Second}
	s := &stats{}

	// Seed initial data.
	log.Println("loadgen: seeding initial users and products...")
	seedUsers(client, targetURL, s, 10)
	seedProducts(client, targetURL, s, 20)

	log.Printf("loadgen: seeded %d users, %d products", s.userIDs.Load(), s.productIDs.Load())

	// Rate limiter: rps requests per second spread across goroutines.
	interval := time.Second / time.Duration(rps)
	ticker := time.NewTicker(interval)
	defer ticker.Stop()

	// Stats reporter.
	go func() {
		reportTicker := time.NewTicker(10 * time.Second)
		defer reportTicker.Stop()
		var lastReqs, lastErrs int64
		for range reportTicker.C {
			reqs := s.requests.Load()
			errs := s.errors.Load()
			log.Printf("loadgen: total_requests=%d (+%d) errors=%d (+%d)",
				reqs, reqs-lastReqs, errs, errs-lastErrs)
			lastReqs = reqs
			lastErrs = errs
		}
	}()

	// Worker pool.
	var wg sync.WaitGroup
	stopCh := make(chan struct{})

	for i := 0; i < concurrency; i++ {
		wg.Add(1)
		go func(workerID int) {
			defer wg.Done()
			for {
				select {
				case <-stopCh:
					return
				case <-ticker.C:
					runJourney(client, targetURL, s)
				}
			}
		}(i)
	}

	// Wait for shutdown signal.
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	<-sigCh

	log.Println("loadgen: shutting down...")
	close(stopCh)
	wg.Wait()
	log.Printf("loadgen: stopped. total_requests=%d errors=%d", s.requests.Load(), s.errors.Load())
}

// runJourney simulates a random user journey.
func runJourney(client *http.Client, baseURL string, s *stats) {
	maxUsers := s.userIDs.Load()
	maxProducts := s.productIDs.Load()
	if maxUsers == 0 || maxProducts == 0 {
		return
	}

	// Pick random action weights:
	// 40% browse products, 20% get product, 15% get user, 25% create order
	r := rand.Float64()
	switch {
	case r < 0.40:
		doGet(client, baseURL+"/products", s)
	case r < 0.60:
		id := rand.Int63n(maxProducts) + 1
		doGet(client, fmt.Sprintf("%s/products/%d", baseURL, id), s)
	case r < 0.75:
		id := rand.Int63n(maxUsers) + 1
		doGet(client, fmt.Sprintf("%s/users/%d", baseURL, id), s)
	default:
		userID := rand.Int63n(maxUsers) + 1
		productID := rand.Int63n(maxProducts) + 1
		qty := rand.Intn(5) + 1
		createOrder(client, baseURL, s, int(userID), int(productID), qty)
	}
}

func doGet(client *http.Client, url string, s *stats) {
	s.requests.Add(1)
	resp, err := client.Get(url)
	if err != nil {
		s.errors.Add(1)
		return
	}
	resp.Body.Close()
	if resp.StatusCode >= 400 {
		s.errors.Add(1)
	}
}

func createOrder(client *http.Client, baseURL string, s *stats, userID, productID, qty int) {
	s.requests.Add(1)
	payload, _ := json.Marshal(map[string]int{
		"user_id":    userID,
		"product_id": productID,
		"quantity":   qty,
	})

	resp, err := client.Post(baseURL+"/orders", "application/json", bytes.NewReader(payload))
	if err != nil {
		s.errors.Add(1)
		return
	}
	resp.Body.Close()
	if resp.StatusCode >= 400 {
		s.errors.Add(1)
	}
}

func seedUsers(client *http.Client, baseURL string, s *stats, count int) {
	for i := 1; i <= count; i++ {
		payload, _ := json.Marshal(map[string]string{
			"email": fmt.Sprintf("user%d@shopsim.local", i),
			"name":  fmt.Sprintf("User %d", i),
		})

		resp, err := client.Post(baseURL+"/users", "application/json", bytes.NewReader(payload))
		if err != nil {
			log.Printf("loadgen: seed user %d failed: %v", i, err)
			continue
		}
		resp.Body.Close()
		if resp.StatusCode < 300 {
			s.userIDs.Add(1)
		}
	}
}

func seedProducts(client *http.Client, baseURL string, s *stats, count int) {
	categories := []string{"Electronics", "Books", "Clothing", "Home", "Sports"}
	for i := 1; i <= count; i++ {
		cat := categories[rand.Intn(len(categories))]
		payload, _ := json.Marshal(map[string]interface{}{
			"name":        fmt.Sprintf("%s Item %d", cat, i),
			"description": fmt.Sprintf("A fine %s product #%d", cat, i),
			"price":       float64(rand.Intn(9900)+100) / 100.0,
			"stock":       rand.Intn(500) + 10,
		})

		resp, err := client.Post(baseURL+"/products", "application/json", bytes.NewReader(payload))
		if err != nil {
			log.Printf("loadgen: seed product %d failed: %v", i, err)
			continue
		}
		resp.Body.Close()
		if resp.StatusCode < 300 {
			s.productIDs.Add(1)
		}
	}
}
