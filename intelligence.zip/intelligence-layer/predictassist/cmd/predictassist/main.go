// Command predictassist is the main PredictAssist server binary. It ingests
// OpenTelemetry data, computes behavioural features, detects anomalies,
// correlates them into incident fingerprints, enriches predictions via LLM
// reasoning, and exposes gRPC/REST APIs.
package main

import (
	"context"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/ClickHouse/clickhouse-go/v2"
	"github.com/nats-io/nats.go"
	"github.com/redis/go-redis/v9"
	"github.com/spf13/viper"
	"go.uber.org/zap"
	"google.golang.org/grpc"

	"github.com/harshitjindal/predictassist/internal/api"
	"github.com/harshitjindal/predictassist/internal/correlator"
	"github.com/harshitjindal/predictassist/internal/detector"
	"github.com/harshitjindal/predictassist/internal/events"
	"github.com/harshitjindal/predictassist/internal/features"
	"github.com/harshitjindal/predictassist/internal/ingestion"
	"github.com/harshitjindal/predictassist/internal/reasoner"
	"github.com/harshitjindal/predictassist/internal/store"
)

func main() {
	// -----------------------------------------------------------------------
	// Logger
	// -----------------------------------------------------------------------
	logger, err := zap.NewProduction()
	if err != nil {
		fmt.Fprintf(os.Stderr, "failed to create logger: %v\n", err)
		os.Exit(1)
	}
	defer logger.Sync() //nolint:errcheck

	// -----------------------------------------------------------------------
	// Configuration
	// -----------------------------------------------------------------------
	viper.SetConfigName("predictassist")
	viper.SetConfigType("yaml")
	viper.AddConfigPath("configs")
	viper.AddConfigPath("/etc/predictassist")
	viper.AddConfigPath(".")

	if err := viper.ReadInConfig(); err != nil {
		logger.Fatal("failed to read config", zap.Error(err))
	}
	logger.Info("loaded configuration", zap.String("file", viper.ConfigFileUsed()))

	// -----------------------------------------------------------------------
	// Root context — cancelled on SIGINT / SIGTERM
	// -----------------------------------------------------------------------
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)

	// -----------------------------------------------------------------------
	// ClickHouse
	// -----------------------------------------------------------------------
	chConn, err := clickhouse.Open(&clickhouse.Options{
		Addr: []string{
			fmt.Sprintf("%s:%d",
				viper.GetString("storage.clickhouse.host"),
				viper.GetInt("storage.clickhouse.port"),
			),
		},
		Auth: clickhouse.Auth{
			Database: viper.GetString("storage.clickhouse.database"),
			Username: viper.GetString("storage.clickhouse.username"),
			Password: viper.GetString("storage.clickhouse.password"),
		},
		MaxOpenConns: viper.GetInt("storage.clickhouse.max_open_conns"),
		DialTimeout:  viper.GetDuration("storage.clickhouse.dial_timeout"),
	})
	if err != nil {
		logger.Fatal("failed to open ClickHouse connection", zap.Error(err))
	}
	if err := chConn.Ping(ctx); err != nil {
		logger.Fatal("failed to ping ClickHouse", zap.Error(err))
	}
	logger.Info("connected to ClickHouse",
		zap.String("host", viper.GetString("storage.clickhouse.host")),
		zap.Int("port", viper.GetInt("storage.clickhouse.port")),
	)

	// -----------------------------------------------------------------------
	// Redis
	// -----------------------------------------------------------------------
	rdb := redis.NewClient(&redis.Options{
		Addr:     viper.GetString("storage.redis.addr"),
		Password: viper.GetString("storage.redis.password"),
		DB:       viper.GetInt("storage.redis.db"),
		PoolSize: viper.GetInt("storage.redis.pool_size"),
	})
	if err := rdb.Ping(ctx).Err(); err != nil {
		logger.Fatal("failed to ping Redis", zap.Error(err))
	}
	logger.Info("connected to Redis", zap.String("addr", viper.GetString("storage.redis.addr")))

	// -----------------------------------------------------------------------
	// ClickHouse Store (with migrations)
	// -----------------------------------------------------------------------
	chStore := store.NewClickHouseStore(chConn)
	if err := chStore.RunMigrations(ctx); err != nil {
		logger.Fatal("failed to run ClickHouse migrations", zap.Error(err))
	}
	logger.Info("ClickHouse migrations applied")

	// -----------------------------------------------------------------------
	// Redis Store
	// -----------------------------------------------------------------------
	redisStore := store.NewRedisStore(rdb)

	// -----------------------------------------------------------------------
	// NATS (JetStream event bus)
	// -----------------------------------------------------------------------
	natsURL := viper.GetString("events.nats.url")
	eventBus, err := events.Connect(ctx, natsURL,
		nats.MaxReconnects(viper.GetInt("events.nats.max_reconnects")),
		nats.ReconnectWait(viper.GetDuration("events.nats.reconnect_wait")),
		nats.Name(viper.GetString("events.nats.client_id")),
	)
	if err != nil {
		logger.Fatal("failed to connect to NATS event bus", zap.Error(err))
	}
	logger.Info("connected to NATS event bus", zap.String("url", natsURL))

	// -----------------------------------------------------------------------
	// OTLP gRPC receiver (TelemetrySource)
	// -----------------------------------------------------------------------
	otlpPort := viper.GetInt("ingestion.otlp.grpc_port")
	otlpReceiver := ingestion.NewOTLPReceiver(&ingestion.OTLPReceiverConfig{
		Port:          otlpPort,
		ChannelBuffer: 4096,
	})
	if err := otlpReceiver.Start(ctx); err != nil {
		logger.Fatal("failed to start OTLP receiver", zap.Error(err))
	}
	logger.Info("OTLP gRPC receiver started", zap.Int("port", otlpPort))

	// -----------------------------------------------------------------------
	// Batch Writer (OTLPReceiver → ClickHouse)
	// -----------------------------------------------------------------------
	batchWriter := ingestion.NewBatchWriter(otlpReceiver, chStore, &ingestion.BatchWriterConfig{
		BatchSize:     viper.GetInt("ingestion.batch.max_size"),
		FlushInterval: viper.GetDuration("ingestion.batch.flush_interval"),
	})
	go batchWriter.Run(ctx)

	// -----------------------------------------------------------------------
	// Feature Engine
	// -----------------------------------------------------------------------
	featureWindows := []time.Duration{1 * time.Minute, 5 * time.Minute, 15 * time.Minute}
	featureEngine := features.NewEngine(chStore, redisStore, features.EngineConfig{
		ComputeInterval: viper.GetDuration("features.computation_interval"),
		Windows:         featureWindows,
	})
	go featureEngine.Run(ctx)
	logger.Info("feature engine started",
		zap.Duration("interval", viper.GetDuration("features.computation_interval")),
	)

	// -----------------------------------------------------------------------
	// Anomaly Detector
	// -----------------------------------------------------------------------
	detectorEngine := detector.NewEngine(chStore, redisStore, eventBus, detector.EngineConfig{
		EvalInterval:   viper.GetDuration("detection.evaluation_interval"),
		BaselineWindow: viper.GetDuration("detection.zscore.baseline_window"),
		MinDataPoints:  viper.GetInt("detection.zscore.min_data_points"),
	})
	go detectorEngine.Run(ctx)
	logger.Info("anomaly detector started",
		zap.Duration("interval", viper.GetDuration("detection.evaluation_interval")),
	)

	// -----------------------------------------------------------------------
	// Incident Correlator
	// -----------------------------------------------------------------------
	correlatorEngine := correlator.NewEngine(chStore, eventBus, correlator.EngineConfig{
		EvalInterval:   viper.GetDuration("correlation.time_window"),
		MinConfidence:  viper.GetFloat64("correlation.min_similarity"),
	})
	go correlatorEngine.Run(ctx)
	logger.Info("incident correlator started",
		zap.Int("fingerprints", len(correlatorEngine.Fingerprints())),
	)

	// -----------------------------------------------------------------------
	// LLM Reasoner
	// -----------------------------------------------------------------------
	llmProvider := selectLLMProvider()
	reasonerCache := reasoner.NewCache(rdb)
	reasonerEngine := reasoner.NewEngine(llmProvider, chStore, eventBus, reasonerCache, reasoner.EngineConfig{
		Timeout:          viper.GetDuration("reasoner.timeout"),
		MaxContextTokens: viper.GetInt("reasoner.max_tokens"),
		CacheTTL:         10 * time.Minute,
	})
	go reasonerEngine.Run(ctx)
	logger.Info("LLM reasoner started", zap.String("provider", llmProvider.Name()))

	// -----------------------------------------------------------------------
	// gRPC API server
	// -----------------------------------------------------------------------
	grpcPort := viper.GetInt("api.grpc_port")
	grpcLis, err := net.Listen("tcp", fmt.Sprintf(":%d", grpcPort))
	if err != nil {
		logger.Fatal("failed to listen on gRPC API port", zap.Int("port", grpcPort), zap.Error(err))
	}
	grpcServer := grpc.NewServer()
	// TODO: Register Protobuf-generated service implementations here.
	go func() {
		logger.Info("gRPC API server listening", zap.Int("port", grpcPort))
		if err := grpcServer.Serve(grpcLis); err != nil {
			logger.Error("gRPC API server error", zap.Error(err))
		}
	}()

	// -----------------------------------------------------------------------
	// REST API server (Gin)
	// -----------------------------------------------------------------------
	restPort := viper.GetInt("api.rest_port")
	apiServer := api.NewServer(chStore, correlatorEngine, api.ServerConfig{
		Port:         restPort,
		ReadTimeout:  viper.GetDuration("api.read_timeout"),
		WriteTimeout: viper.GetDuration("api.write_timeout"),
		CORSOrigins:  viper.GetStringSlice("api.cors.allowed_origins"),
	})
	restServer := &http.Server{
		Addr:         fmt.Sprintf(":%d", restPort),
		Handler:      apiServer.Handler(),
		ReadTimeout:  viper.GetDuration("api.read_timeout"),
		WriteTimeout: viper.GetDuration("api.write_timeout"),
	}
	go func() {
		logger.Info("REST API server listening", zap.Int("port", restPort))
		if err := restServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			logger.Error("REST API server error", zap.Error(err))
		}
	}()

	// -----------------------------------------------------------------------
	// Log readiness
	// -----------------------------------------------------------------------
	logger.Info("PredictAssist server is ready",
		zap.Int("otlp_port", otlpPort),
		zap.Int("grpc_port", grpcPort),
		zap.Int("rest_port", restPort),
	)

	// -----------------------------------------------------------------------
	// Wait for shutdown signal
	// -----------------------------------------------------------------------
	sig := <-sigCh
	logger.Info("received shutdown signal", zap.String("signal", sig.String()))
	cancel()

	// Give in-flight work up to 15 seconds to finish.
	shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer shutdownCancel()

	// Graceful shutdown in reverse dependency order.
	if err := restServer.Shutdown(shutdownCtx); err != nil {
		logger.Error("REST API server shutdown error", zap.Error(err))
	}
	grpcServer.GracefulStop()
	if err := otlpReceiver.Stop(shutdownCtx); err != nil {
		logger.Error("OTLP receiver stop error", zap.Error(err))
	}

	eventBus.Close()
	if err := rdb.Close(); err != nil {
		logger.Error("Redis close error", zap.Error(err))
	}
	if err := chConn.Close(); err != nil {
		logger.Error("ClickHouse close error", zap.Error(err))
	}

	logger.Info("PredictAssist server stopped")
}

// selectLLMProvider returns the configured LLM provider based on config.
func selectLLMProvider() reasoner.LLMProvider {
	providerName := viper.GetString("reasoner.provider")
	switch providerName {
	case "ollama":
		return reasoner.NewOllamaProvider(reasoner.OllamaConfig{
			BaseURL: viper.GetString("reasoner.ollama_url"),
			Model:   viper.GetString("reasoner.model"),
			Timeout: viper.GetDuration("reasoner.timeout"),
		})
	case "openai":
		return reasoner.NewOpenAIProvider(reasoner.OpenAIConfig{
			BaseURL: viper.GetString("reasoner.openai_url"),
			APIKey:  viper.GetString("reasoner.api_key"),
			Model:   viper.GetString("reasoner.model"),
			Timeout: viper.GetDuration("reasoner.timeout"),
		})
	default:
		// NoOp provider for development or when no LLM is configured.
		return reasoner.NewNoOpProvider()
	}
}
