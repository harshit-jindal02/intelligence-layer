#!/bin/bash
export PATH="/usr/local/go/bin:$HOME/go/bin:$PATH"
cd /home/harshjindal/workspace/intelligence-layer/predictassist
exec "$@"
