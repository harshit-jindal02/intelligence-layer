// Package chaos provides a configurable failure injection framework for
// ShopSim. Each chaos mode produces a distinct telemetry fingerprint that
// PredictAssist can learn to recognize and predict.
package chaos

import (
	"math/rand"
	"sync"
	"time"
)

// Injector manages active chaos injections.
type Injector struct {
	mu     sync.RWMutex
	modes  map[string]*Injection
}

// Injection represents an active chaos injection.
type Injection struct {
	Mode      string    `json:"mode"`
	StartedAt time.Time `json:"started_at"`
	Config    Config    `json:"config"`
}

// Config holds chaos injection parameters.
type Config struct {
	// Intensity is a 0.0-1.0 value controlling how severe the injection is.
	Intensity float64 `json:"intensity"`

	// Ramp enables gradual increase of intensity over time (more realistic).
	Ramp bool `json:"ramp"`

	// RampDuration is how long it takes to reach full intensity.
	RampDuration time.Duration `json:"ramp_duration,omitempty"`
}

// NewInjector creates a new chaos injector.
func NewInjector() *Injector {
	return &Injector{
		modes: make(map[string]*Injection),
	}
}

// Activate starts a chaos injection mode.
func (inj *Injector) Activate(mode string, cfg Config) {
	inj.mu.Lock()
	defer inj.mu.Unlock()
	if cfg.Intensity == 0 {
		cfg.Intensity = 0.5
	}
	inj.modes[mode] = &Injection{
		Mode:      mode,
		StartedAt: time.Now(),
		Config:    cfg,
	}
}

// Deactivate stops a chaos injection mode.
func (inj *Injector) Deactivate(mode string) {
	inj.mu.Lock()
	defer inj.mu.Unlock()
	delete(inj.modes, mode)
}

// Reset clears all active chaos injections.
func (inj *Injector) Reset() {
	inj.mu.Lock()
	defer inj.mu.Unlock()
	inj.modes = make(map[string]*Injection)
}

// IsActive returns whether a mode is currently active.
func (inj *Injector) IsActive(mode string) bool {
	inj.mu.RLock()
	defer inj.mu.RUnlock()
	_, ok := inj.modes[mode]
	return ok
}

// ActiveModes returns all active chaos modes.
func (inj *Injector) ActiveModes() []Injection {
	inj.mu.RLock()
	defer inj.mu.RUnlock()
	var result []Injection
	for _, v := range inj.modes {
		result = append(result, *v)
	}
	return result
}

// CurrentIntensity returns the effective intensity of a mode, accounting for
// ramp-up time.
func (inj *Injector) CurrentIntensity(mode string) float64 {
	inj.mu.RLock()
	defer inj.mu.RUnlock()

	injection, ok := inj.modes[mode]
	if !ok {
		return 0
	}

	if !injection.Config.Ramp || injection.Config.RampDuration == 0 {
		return injection.Config.Intensity
	}

	elapsed := time.Since(injection.StartedAt)
	progress := float64(elapsed) / float64(injection.Config.RampDuration)
	if progress > 1 {
		progress = 1
	}

	return injection.Config.Intensity * progress
}

// ShouldInject returns true with probability equal to the current intensity.
func (inj *Injector) ShouldInject(mode string) bool {
	intensity := inj.CurrentIntensity(mode)
	if intensity == 0 {
		return false
	}
	return rand.Float64() < intensity
}

// Chaos mode constants.
const (
	ModeDBSlow         = "db-slow"
	ModeMemoryLeak     = "memory-leak"
	ModeConnectionPool = "connection-pool"
	ModeCascade        = "cascade"
	ModeCPUSpike       = "cpu-spike"
	ModeIntermittent   = "intermittent"
	ModeLogFlood       = "log-flood"
	ModeDependencySlow = "dependency-slow"
)
