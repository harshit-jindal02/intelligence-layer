package chaos

import (
	"math/rand"
	"runtime"
	"time"

	"go.uber.org/zap"
)

// Effects provides methods that ShopSim services call at request processing
// points to inject chaos behaviour based on active modes.
type Effects struct {
	inj    *Injector
	logger *zap.Logger
}

// NewEffects creates a new effects helper.
func NewEffects(inj *Injector, logger *zap.Logger) *Effects {
	return &Effects{inj: inj, logger: logger}
}

// MaybeSlowDB adds artificial latency to simulate slow DB queries.
// Returns the added delay duration (0 if not active).
func (e *Effects) MaybeSlowDB() time.Duration {
	if !e.inj.ShouldInject(ModeDBSlow) {
		return 0
	}
	intensity := e.inj.CurrentIntensity(ModeDBSlow)
	delay := time.Duration(200+rand.Intn(800)) * time.Millisecond
	delay = time.Duration(float64(delay) * intensity)
	e.logger.Warn("chaos: injecting DB slowdown", zap.Duration("delay", delay))
	time.Sleep(delay)
	return delay
}

// MaybeError returns true if the request should return a 500 error
// (for intermittent failure mode).
func (e *Effects) MaybeError() bool {
	if !e.inj.ShouldInject(ModeIntermittent) {
		return false
	}
	e.logger.Warn("chaos: injecting intermittent error")
	return true
}

// MaybeCascadeError returns true if a cascade failure should be injected.
func (e *Effects) MaybeCascadeError() bool {
	if !e.inj.ShouldInject(ModeCascade) {
		return false
	}
	e.logger.Warn("chaos: injecting cascade failure")
	return true
}

// MaybeSlowDependency adds latency to simulate a slow downstream service.
func (e *Effects) MaybeSlowDependency() time.Duration {
	if !e.inj.ShouldInject(ModeDependencySlow) {
		return 0
	}
	intensity := e.inj.CurrentIntensity(ModeDependencySlow)
	delay := time.Duration(500+rand.Intn(2000)) * time.Millisecond
	delay = time.Duration(float64(delay) * intensity)
	e.logger.Warn("chaos: injecting slow dependency", zap.Duration("delay", delay))
	time.Sleep(delay)
	return delay
}

// MaybeLogFlood emits a burst of log lines to simulate log volume spikes.
func (e *Effects) MaybeLogFlood() {
	if !e.inj.ShouldInject(ModeLogFlood) {
		return
	}
	intensity := e.inj.CurrentIntensity(ModeLogFlood)
	count := int(50 * intensity)
	for i := 0; i < count; i++ {
		e.logger.Warn("chaos: log flood event",
			zap.Int("flood_index", i),
			zap.String("noise", randomString(100)),
		)
	}
}

// StartCPUSpike launches goroutines that do busy work (call once on activation).
func (e *Effects) StartCPUSpike() {
	if !e.inj.IsActive(ModeCPUSpike) {
		return
	}
	intensity := e.inj.CurrentIntensity(ModeCPUSpike)
	numGoroutines := int(float64(runtime.NumCPU()) * intensity)
	if numGoroutines < 1 {
		numGoroutines = 1
	}
	for i := 0; i < numGoroutines; i++ {
		go func() {
			for e.inj.IsActive(ModeCPUSpike) {
				// Busy work.
				_ = fibonacci(30)
				runtime.Gosched()
			}
		}()
	}
	e.logger.Warn("chaos: started CPU spike goroutines", zap.Int("count", numGoroutines))
}

// StartMemoryLeak starts allocating memory that isn't freed.
func (e *Effects) StartMemoryLeak() {
	if !e.inj.IsActive(ModeMemoryLeak) {
		return
	}
	go func() {
		var leak [][]byte
		for e.inj.IsActive(ModeMemoryLeak) {
			chunk := make([]byte, 1024*1024) // 1MB per tick
			for i := range chunk {
				chunk[i] = byte(i % 256)
			}
			leak = append(leak, chunk)
			e.logger.Warn("chaos: memory leak", zap.Int("chunks", len(leak)), zap.Int("mb", len(leak)))
			time.Sleep(1 * time.Second)
		}
		// Release on deactivation.
		leak = nil
		runtime.GC()
	}()
}

func fibonacci(n int) int {
	if n <= 1 {
		return n
	}
	return fibonacci(n-1) + fibonacci(n-2)
}

func randomString(n int) string {
	const letters = "abcdefghijklmnopqrstuvwxyz0123456789"
	b := make([]byte, n)
	for i := range b {
		b[i] = letters[rand.Intn(len(letters))]
	}
	return string(b)
}
