package chaos

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

// RegisterRoutes wires up chaos injection HTTP endpoints.
func RegisterRoutes(router *gin.Engine, inj *Injector) {
	chaos := router.Group("/chaos")
	{
		chaos.POST("/db-slow", func(c *gin.Context) { activateHandler(c, inj, ModeDBSlow) })
		chaos.POST("/memory-leak", func(c *gin.Context) { activateHandler(c, inj, ModeMemoryLeak) })
		chaos.POST("/connection-pool", func(c *gin.Context) { activateHandler(c, inj, ModeConnectionPool) })
		chaos.POST("/cascade", func(c *gin.Context) { activateHandler(c, inj, ModeCascade) })
		chaos.POST("/cpu-spike", func(c *gin.Context) { activateHandler(c, inj, ModeCPUSpike) })
		chaos.POST("/intermittent", func(c *gin.Context) { activateHandler(c, inj, ModeIntermittent) })
		chaos.POST("/log-flood", func(c *gin.Context) { activateHandler(c, inj, ModeLogFlood) })
		chaos.POST("/dependency-slow", func(c *gin.Context) { activateHandler(c, inj, ModeDependencySlow) })
		chaos.POST("/reset", func(c *gin.Context) {
			inj.Reset()
			c.JSON(http.StatusOK, gin.H{"status": "all chaos modes deactivated"})
		})
		chaos.GET("/status", func(c *gin.Context) {
			c.JSON(http.StatusOK, gin.H{
				"active": inj.ActiveModes(),
			})
		})
	}
}

func activateHandler(c *gin.Context, inj *Injector, mode string) {
	var cfg Config
	if err := c.ShouldBindJSON(&cfg); err != nil {
		// Use defaults if no body.
		cfg = Config{Intensity: 0.5, Ramp: true, RampDuration: 60_000_000_000} // 1 min ramp
	}
	inj.Activate(mode, cfg)
	c.JSON(http.StatusOK, gin.H{
		"status": "activated",
		"mode":   mode,
		"config": cfg,
	})
}
