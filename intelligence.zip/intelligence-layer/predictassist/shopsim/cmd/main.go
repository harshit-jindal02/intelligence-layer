// Command shopsim runs all ShopSim microservices in a single process.
// Each service registers its routes on a shared gin.Engine. This simplifies
// local development and Docker deployment while preserving the logical
// separation between services.
package main

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"
	"go.uber.org/zap"

	"github.com/harshitjindal/predictassist/shopsim/chaos"
	"github.com/harshitjindal/predictassist/shopsim/db"
	"github.com/harshitjindal/predictassist/shopsim/services"
	"github.com/harshitjindal/predictassist/shopsim/telemetry"
)

func envOrDefault(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func main() {
	logger, err := zap.NewProduction()
	if err != nil {
		fmt.Fprintf(os.Stderr, "failed to create logger: %v\n", err)
		os.Exit(1)
	}
	defer logger.Sync() //nolint:errcheck

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// -----------------------------------------------------------------------
	// Configuration from environment
	// -----------------------------------------------------------------------
	port := envOrDefault("PORT", "8080")
	postgresDSN := envOrDefault("POSTGRES_DSN", "postgres://shopsim:shopsim@localhost:5432/shopsim?sslmode=disable")
	redisAddr := envOrDefault("REDIS_ADDR", "localhost:6379")
	otelEndpoint := envOrDefault("OTEL_ENDPOINT", "localhost:4317")
	paymentURL := envOrDefault("PAYMENT_URL", fmt.Sprintf("http://localhost:%s", port))
	serviceName := envOrDefault("SERVICE_NAME", "shopsim")

	// -----------------------------------------------------------------------
	// OpenTelemetry
	// -----------------------------------------------------------------------
	shutdownTelemetry, err := telemetry.InitTelemetry(ctx, serviceName, otelEndpoint)
	if err != nil {
		logger.Warn("failed to initialize telemetry, continuing without it", zap.Error(err))
		shutdownTelemetry = func(_ context.Context) error { return nil }
	} else {
		logger.Info("telemetry initialized", zap.String("endpoint", otelEndpoint))
	}

	// -----------------------------------------------------------------------
	// PostgreSQL
	// -----------------------------------------------------------------------
	pool, err := db.Connect(ctx, postgresDSN, logger)
	if err != nil {
		logger.Fatal("failed to connect to PostgreSQL", zap.Error(err))
	}
	defer pool.Close()

	// -----------------------------------------------------------------------
	// Redis
	// -----------------------------------------------------------------------
	rdb := redis.NewClient(&redis.Options{Addr: redisAddr})
	if err := rdb.Ping(ctx).Err(); err != nil {
		logger.Warn("failed to connect to Redis, cache disabled", zap.Error(err))
	} else {
		logger.Info("connected to Redis", zap.String("addr", redisAddr))
	}
	defer rdb.Close()

	// -----------------------------------------------------------------------
	// Services
	// -----------------------------------------------------------------------
	router := gin.New()
	router.Use(gin.Recovery())

	// Health check
	router.GET("/healthz", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"status": "ok", "ts": time.Now().UTC().Format(time.RFC3339)})
	})

	// Chaos injection
	chaosInjector := chaos.NewInjector()
	chaos.RegisterRoutes(router, chaosInjector)
	_ = chaos.NewEffects(chaosInjector, logger) // Services will use effects for injection

	orderSvc, err := services.NewOrderService(pool, logger, paymentURL)
	if err != nil {
		logger.Fatal("failed to create order service", zap.Error(err))
	}
	orderSvc.RegisterRoutes(router)

	paymentSvc, err := services.NewPaymentService(pool, logger)
	if err != nil {
		logger.Fatal("failed to create payment service", zap.Error(err))
	}
	paymentSvc.RegisterRoutes(router)

	productSvc, err := services.NewProductService(pool, rdb, logger)
	if err != nil {
		logger.Fatal("failed to create product service", zap.Error(err))
	}
	productSvc.RegisterRoutes(router)

	userSvc, err := services.NewUserService(pool, logger)
	if err != nil {
		logger.Fatal("failed to create user service", zap.Error(err))
	}
	userSvc.RegisterRoutes(router)

	// -----------------------------------------------------------------------
	// HTTP server
	// -----------------------------------------------------------------------
	srv := &http.Server{
		Addr:         ":" + port,
		Handler:      router,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	go func() {
		logger.Info("ShopSim listening", zap.String("port", port))
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			logger.Fatal("server error", zap.Error(err))
		}
	}()

	// -----------------------------------------------------------------------
	// Graceful shutdown
	// -----------------------------------------------------------------------
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)

	sig := <-sigCh
	logger.Info("received shutdown signal", zap.String("signal", sig.String()))
	cancel()

	shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer shutdownCancel()

	if err := srv.Shutdown(shutdownCtx); err != nil {
		logger.Error("server shutdown error", zap.Error(err))
	}
	if err := shutdownTelemetry(shutdownCtx); err != nil {
		logger.Error("telemetry shutdown error", zap.Error(err))
	}

	logger.Info("ShopSim stopped")
}
