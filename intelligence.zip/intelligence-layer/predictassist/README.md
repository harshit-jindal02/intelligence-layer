# PredictAssist

**Proactive Intelligence Layer** — detects anomalies, predicts incidents, and
generates actionable insights from OpenTelemetry data.

Part of the three-product pipeline:
**TraceAssist** (data) → **PredictAssist** (intelligence) → **toilAssist** (action)

## Quickstart

```bash
# Start all infrastructure + services
cd deployments
docker compose up -d

# Check health
curl http://localhost:8090/healthz     # PredictAssist REST
curl http://localhost:8080/healthz     # ShopSim

# View ClickHouse data (after loadgen runs for a few minutes)
docker exec -it deployments-clickhouse-1 clickhouse-client \
  --query "SELECT count() FROM raw_logs"
```

## Architecture

```
ShopSim (sample app)
    │ OTel SDK (logs, metrics, traces)
    ▼
PredictAssist
    ├── OTLP Receiver (:4317)      ← ingests telemetry
    ├── Normalizer                  ← OTLP → internal models
    ├── Batch Writer               ← writes to ClickHouse
    ├── Feature Engine (planned)   ← computes behavioral features
    ├── Anomaly Detector (planned) ← statistical detection
    ├── Correlator (planned)       ← pattern matching
    ├── LLM Reasoner (planned)     ← natural language insights
    ├── gRPC API (:9090)
    └── REST API (:8090)

Infrastructure
    ├── ClickHouse  ← analytical storage
    ├── Redis       ← hot cache
    ├── NATS        ← event bus (JetStream)
    └── PostgreSQL  ← ShopSim data
```

## Project Structure

```
predictassist/
├── cmd/
│   ├── predictassist/   # Main server binary
│   └── loadgen/         # Traffic generator for ShopSim
├── internal/
│   ├── ingestion/       # OTLP receiver, normalizer, batch writer
│   ├── events/          # NATS JetStream event bus
│   ├── models/          # Internal telemetry models
│   └── store/           # ClickHouse + Redis storage
├── pkg/models/          # Public API models (anomaly, prediction)
├── shopsim/             # Sample e-commerce application
│   ├── cmd/             # ShopSim entrypoint
│   ├── services/        # Order, Payment, Product, User services
│   ├── db/              # PostgreSQL schema + connection
│   └── telemetry/       # OpenTelemetry SDK setup
├── configs/             # YAML configuration
└── deployments/         # Docker Compose + Dockerfiles
```

## Development

```bash
# Build all binaries
make build

# Run tests
make test

# Lint
make lint

# Start infrastructure only
cd deployments && docker compose up clickhouse redis nats postgres -d

# Run PredictAssist locally
go run ./cmd/predictassist

# Run ShopSim locally
POSTGRES_DSN="postgres://shopsim:shopsim@localhost:5432/shopsim?sslmode=disable" \
  go run ./shopsim/cmd

# Run load generator
TARGET_URL=http://localhost:8080 go run ./cmd/loadgen
```

## Configuration

See [configs/predictassist.yaml](configs/predictassist.yaml) for all options.

Key environment variable overrides (for Docker):
- `PA_STORAGE_CLICKHOUSE_HOST` / `PA_STORAGE_CLICKHOUSE_PORT`
- `PA_STORAGE_REDIS_ADDR`
- `PA_EVENTS_NATS_URL`
- `PA_INGESTION_OTLP_GRPC_PORT`

## Sprint Roadmap

| Sprint | Weeks | Goal |
|--------|-------|------|
| 1 ✅ | 1-2 | Foundation: ShopSim + ingestion pipeline + docker stack |
| 2 | 3-4 | Feature engine + Z-score detection + first chaos endpoint |
| 3 | 5-6 | Multi-signal correlation + more chaos modes |
| 4 | 7-8 | Incident fingerprinting + pattern matching |
| 5 | 9-10 | LLM reasoning layer + RAG |
| 6 | 11-12 | Full API + integration prep for TraceAssist/toilAssist |
